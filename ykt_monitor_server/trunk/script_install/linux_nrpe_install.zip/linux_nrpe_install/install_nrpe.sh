#!/bin/sh
#nrpe install script 
Os_is=`uname`
Nagios_is=`grep nagios /etc/passwd | wc -l` 
if [ "$Os_is" = "Linux" ]
then
  ipadd=$(ifconfig | sed -n '2p'|awk '{print $2}'|awk -F: '{print $2}')
  if [ $Nagios_is = 0 ]
  then
    useradd nagios -s /sbin/nologin
  fi
elif [ "$Os_is" = "FreeBSD" ]
   then
    ipadd=$(ifconfig | sed -n '4p'|awk '{print $2}')
    if [ $Nagios_is = 0 ]
    then
    /usr/sbin/pw useradd nagios -s /sbin/nologin
    fi
else echo "this is other os,please modify the script"
exit 1
fi 
PREFIX=/usr/local/nagios
#install nagios-plugins
tar zxvf nagios-plugins-1.4.14.tar.gz
cd nagios-plugins-1.4.14
./configure --with-nagios-user=nagios --with-nagios-group=nagios --enable-redhat-pthread-workaround
make && make install
cd ..
echo "nagios-plugins is ok!"
sleep 3 
#install nrpe
tar zxvf nrpe-2.12.tar.gz
cd nrpe-2.12
./configure --enable-command-args
make all
make install-plugin
make install-daemon
make install-daemon-config 
echo "nrpe install ok..!"
sleep 3 
cd ..
if [ ! -d $PREFIX/etc ]
   then
     mkdir $PREFIX/etc
fi 
#setting nrpe
cp check_mem.pl $PREFIX/libexec
cp nrpe.cfg $PREFIX/etc
chmod -R +x $PREFIX/libexec
#running nrpe
$PREFIX/bin/nrpe -c $PREFIX/etc/nrpe.cfg -d
echo "nrpe is running!!!"
