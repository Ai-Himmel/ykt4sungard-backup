write-host "WARN: Everything is not going to be fine!"
exit 1
