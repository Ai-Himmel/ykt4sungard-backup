#!/bin/bash
bankid=$1
bankdate=$2
dzfile=$3
outfile=$4
sed -e 's/ //g' $dzfile|sed -e 's/\t//g'|awk -F[\|] -v bankid=$bankid -v bankdate=$bankdate '
    BEGIN {rowno=0;bankcnt=0;bankamt=0;}
    {	
	if($0~/00/)
	{
		if($6 == '01')
		{
			amount=$5/100.0;
			bankcnt ++;
			bankamt += amount;
			banksno = sprintf("%c%s%c",39,$2,39);
			transdate =bankdate;
			localsno =sprintf("%c%s%s%c",39,bankdate,$1,39);
			bankcardno=sprintf("%c%s%c",39,$4,39);
			printf("INS:(bankid,bankdate,recordno,amount,transdate,banksno,localsno,bankcardno) ");
			print "values (",bankid,",",bankdate,",",bankcnt,",",amount,",",transdate,",",banksno,",",localsno,",",bankcardno,")";
		}
	} 
    }
   	END {printf("UPD:set bankcnt=%d,bankamt=%.2lf where bankid=%d and bankdate=%d",bankcnt,bankamt,bankid,bankdate);} 
	' >$outfile

if [ $? == 0 ];then
	echo "success"
else
	echo "failed"
fi 

