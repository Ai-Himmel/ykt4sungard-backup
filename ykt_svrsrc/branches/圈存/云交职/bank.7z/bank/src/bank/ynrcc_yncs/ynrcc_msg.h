/*****************************8583def.h******************************/

#ifndef _MY8583_H
#define _MY8583_H

#include <stdio.h>


#define MY_BITGET(p,n)  ((p)[(n-1)/8]&(0x80>>((n-1)%8)))       //ȡbitλ
#define MY_BITSET(p,n)  ((p)[(n-1)/8]|=(0x80>>((n-1)%8)))      //��bitλ
#define MY_BITCLR(p,n)  ((p)[(n-1)/8]&=(~(0x80>>((n-1)%8))))   //��bitλ


#define ISO_FLDS 128

#define TYP_BIT  0
#define TYP_BCD  1
#define TYP_ASC  2
#define TYP_BIN  3

#define FMT_FIXED 0
#define FMT_LLVAR 2
#define FMT_LLLVAR 3


typedef struct ISO_DEF {
	short typ;
	short fmt;
	int   len;
	const char *dsc;
} ISO_DEF;


typedef struct ISO_MSG {
	struct tagISO_FLD {
		int len;
		unsigned char *buf;
	} fld[ISO_FLDS+1];

} ISO_MSG;

extern ISO_DEF s_isodef[];


void my8583_init(ISO_MSG *m);
int my8583_set(ISO_MSG *m, int idx, const unsigned char *data, int len);
int my8583_get(const ISO_MSG *m, int idx, unsigned char *data, int len);
int my8583_pack(const ISO_MSG *m, char *buf, int buf_len);
int my8583_unpack(ISO_MSG *m, char *buf, int buf_len);
void my8583_dump(FILE *fp, ISO_MSG *m);
void my8583_free(ISO_MSG *m);


#endif /* my8583.h */
