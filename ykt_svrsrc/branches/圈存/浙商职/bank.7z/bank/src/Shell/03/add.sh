#! /bin/bash
# 数字相加

add ()
{
  let "sum=$1+$2"
  return $sum
}

