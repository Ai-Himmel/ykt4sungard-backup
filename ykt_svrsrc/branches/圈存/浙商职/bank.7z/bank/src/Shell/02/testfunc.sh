#!/bin/bash
echo "$# parameters"					
echo "$@";
