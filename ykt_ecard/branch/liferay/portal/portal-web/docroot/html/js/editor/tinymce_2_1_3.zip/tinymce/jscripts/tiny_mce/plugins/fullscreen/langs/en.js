// UK lang variables

tinyMCE.addToLang('',{
fullscreen_desc : 'Toggle fullscreen mode'
});
