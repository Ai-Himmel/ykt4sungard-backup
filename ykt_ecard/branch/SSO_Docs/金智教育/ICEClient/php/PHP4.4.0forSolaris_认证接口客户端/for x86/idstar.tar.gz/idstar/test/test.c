#include <stdlib.h>
int main()
{
  int a=0;
  int b=a++;
  printf("%d\n",a);
  printf("%d\n",b);
  
}
