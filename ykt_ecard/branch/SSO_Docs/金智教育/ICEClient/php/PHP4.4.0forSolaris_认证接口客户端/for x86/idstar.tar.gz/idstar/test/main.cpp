#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "idstar_im.h"
#include <unistd.h>
#include <signal.h>
int main()
{
   printf("test\n");
   char* url =(char*) ids_GetLoginURL();
   printf("url is %s\n",url);
   ids_FreeString( url );
}


