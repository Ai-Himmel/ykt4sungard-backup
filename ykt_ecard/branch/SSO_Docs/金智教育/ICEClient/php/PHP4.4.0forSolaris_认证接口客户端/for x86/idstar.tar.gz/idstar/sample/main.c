#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "idstar_im.h"

int main()
{
    int i=0;
    struct timeval tv1, tv2;
    //char*  name = ids_GetUserNameByID("amadmin");
    //printf("name is %s\n", name);
    char* url =(char*) ids_GetLoginURL();
    if (ids_CheckPassword("amadmin","111111") == 0)
         {
             printf("password is error\n");
         }
     else
         {
             printf("password is ok\n");
         }
   //gettimeofday(&tv1, 0);
    printf("url is %s\n",url);
    ids_FreeString( url );
    //ids_FreeString(name);
    //gettimeofday(&tv2, 0);
    //printf("use time %ld\n",
    //   ((tv2.tv_sec-tv1.tv_sec)*1000000 + tv2.tv_usec-tv1.tv_usec)/1000 );

    ids_Destory(); 
	return 0;	
}


