#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "idstar_im.h"

int main()
{
	char* name ;
    int i=0;
    struct timeval tv1, tv2;

//    ids_Init("../etc/client.properties");
    name = ids_GetUserNameByID("amadmin");
	printf("name is %s\n", name);
    char* url =(char*) ids_GetLoginURL();
   // gettimeofday(&tv1, 0);
    printf(url);
    ids_FreeString( url );
    //ids_GetUserGroup("nokia0002");
    ids_GetUserByGroupNew("ttt");
    ids_GetUserByGroup("cn=ttt,ou=Groups,dc=wiscom,dc=com");
    //for ( i=0; i<1000; i++){
     //   name = ids_GetUserNameByID("amadmin");
      //  ids_FreeString( name );
    //}

    //gettimeofday(&tv2, 0);
    //printf("use time %ld\n",
     //   ((tv2.tv_sec-tv1.tv_sec)*1000000 + tv2.tv_usec-tv1.tv_usec)/1000 );

    ids_Destory(); 
	return 0;	
}


