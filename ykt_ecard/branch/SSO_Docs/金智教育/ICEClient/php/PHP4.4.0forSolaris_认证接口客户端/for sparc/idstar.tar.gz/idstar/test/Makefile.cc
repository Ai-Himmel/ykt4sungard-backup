all : main
clean: 
	rm main 

main: main.c
	/opt/SUNWspro/bin/cc -xCC -xcsi   -o main   main.c -L/usr/local/lib -lstdc++   -L/opt/SUNWspro/lib   -L../lib -lIdstar   -I../include
