import re
import sys
import time


function_ = [ ]

def AddFunction (type, name, argu):
    tmp = { }
    tmp["type"] = type
    tmp["name"] = name
    tmp["argu"] = argu

    function_.append( tmp )
    
def Convert ( filename, operate ):
    f = file( filename)
    while 1 :
        line=f.readline()
        if not line:
            break

        m = re.search(r"(?P<type>.+)[ ]+(?P<name>\S+)[ ]*\([ ]*(?P<argu>.*)\)[ ]*;$",line)
        if m :
            '''
            print line
            print "type\t=%s" % m.group("type")
            print "name\t=%s" % m.group("name")
            print "argu\t=%s" % m.group("argu")        
            '''
            x = re.match(r"(IDSTAR_API)[ ]*(?P<type>.*)", m.group("type"))
            if x :
                AddFunction( x.group("type"), m.group("name"), m.group("argu") )
            else:
                AddFunction( m.group("type"), m.group("name"), m.group("argu") )
    Output(operate)            

def ParseArgument (argu ):
    if not argu :
        return ( "", "" )
    
    i = 0
    define = ""
    value = ""
    for a in argu.split(","):
        a = a.strip()        
        m = re.match(r"[ ]*(\S+)[ \*]+(\S+)$", a)
        id = ""
        if m :                
            if not ( m.group(2)=="*" or m.group(2)=="**" ) :
                id = m.group(2)

        if not id:
            id = "arg_%d" % i
            i = i + 1
            a = a + " " + id
        
        define = define + "," + a
        value = value + "," + id

    return ( define[1:], value[1:] )


def Output (operate):
    print "/* auto generate by dll_wrap.py %s  */" %  time.ctime()

    if operate=="source":
        print '''

#include "stdlib.h"
#include "dlfcn.h"

#include "XXXXX.h"

#define SOFILE "libIdstar.so"

static void * lib_handler = NULL;

static void* load_library()
{
    lib_handler = dlopen(SOFILE,RTLD_LAZY);
    return lib_handler;
}


static void unload_library()
{
    dlclose( lib_handler );
}

static void* get_function ( char*name)
{
    if( ! lib_handler && !load_library() ) 
        return NULL;
    return  dlsym( lib_handler, name );        
}
'''
        print "\n//function type\n"
        for x  in function_ :
    	    print "typedef %s (*%s_t)(%s);" % ( x["type"], x["name"], x["argu"] )
    
    
        print "\n//function pointer\n"
        for x in function_ :
            print "%s_t p_%s = NULL;" % ( x["name"], x["name"] )


    print "\n// wrap function \n"
    

    for x in function_:
        type = x["type"]
        name = x["name"]
        argu = x["argu"]
        args = [ ]
        define, value = ParseArgument ( argu )
        if operate == "source":       
            print '''\n
%s %s ( %s ) 
{
    if ( ! p_%s ) 
        p_%s = (%s_t) get_function( \"%s\" );

    if ( p_%s )
        return p_%s( %s );
    else
        return (%s)NULL;
}        
    ''' % ( type, name, define, name, name, name, name, name, name, value, type)
        else:
            print "%s %s( %s );\n" % ( type, name, define );

def usage ():
    print "%s filename (source|header)" % sys.argv[0]
    sys.exit()

if __name__=="__main__" :
    if len (sys.argv)!=3 :
        usage()
    
    if sys.argv[2] not in [ "source", "header" ]:
        usage()

    Convert( sys.argv[1] ,sys.argv[2])
