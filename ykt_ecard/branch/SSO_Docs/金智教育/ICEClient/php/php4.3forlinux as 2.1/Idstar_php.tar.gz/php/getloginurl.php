<?php
#dl("libIdstarPhp.so");
ids_Init("../etc/client.properties");
$url = ids_GetLoginURL();
print $url;
print time();
for ( $i=0 ; $i<100; $i++)
    $url = ids_GetLoginURL();
print $url;
print time();
#ids_Destory(); 

?>
