<?php
ids_Init("../etc/client.properties");
$cookies = $_COOKIE['iPlanetDirectoryPro'];
if ( $cookies )
{
	print("ok");
}
else 
{
	print("you must login first");
	$gotoUrl = "http://lah.zty.com/test2.php";
	$url = ids_GetLoginURL()."?goto=".urlencode($gotoUrl);
	echo "<a href=".$url."> Login </a>";

}
?>
