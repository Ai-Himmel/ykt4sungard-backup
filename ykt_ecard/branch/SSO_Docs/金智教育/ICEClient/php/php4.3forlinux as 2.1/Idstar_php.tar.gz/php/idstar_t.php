<?php
dl("../lib/libIdstarPhp.so");
ids_Init("../etc/client.properties");
$url = ids_GetLoginURL();
print $url;
//$name = ids_GetUserNameByID("tjadmin");

//$attr = ids_GetUserAttribute("amadmin","cn");
$isIn=isUserInGroup("dddddd","cn=test,ou=Groups,o=testOrg,dc=zty,dc=com");
//$groups = ids_GetUserGroup("dddddd");
//$currentUser = ids_GetCurrentUser("AQIC5wM2LY4SfczqhuYfcKT97W1eg6hiKCPrjvcoIMUpSFA=");
//$des = ids_DestroySSOToken("AQIC5wM2LY4SfczqhuYfcKT97W1eg6hiKCPrjvcoIMUpSFA=");
//$isE = ids_IsUserExist("dddddddd");
//$token = ids_CreateSSOToken("tjadmin","test");
//$isU = ids_UpdateUserAttribute("dddddd","cn","ddddd","eee");
//$identity = ids_GetUserIdentities("000102");
//$firstIdentity = ids_GetUserFirstIdentity("000104");
//$isAdd = deleteUserAttribute("test","eduPersonOrgDN","030100");
//$isAdd = addGroupToContainer("test2","cn=test,ou=Groups,o=testOrg,dc=zty,dc=com");
//$isAdd = deleteGroupFromContainer("cn=test2,cn=test,ou=Groups,o=testOrg,dc=zty,dc=com");
//$isAdd = addUserToGroup("test","cn=test2,cn=test,ou=Groups,o=testOrg,dc=zty,dc=com");
//$isAdd = deleteUserFromGroup("test","cn=test,ou=Groups,o=testOrg,dc=zty,dc=com");
//$isAdd = deleteUserFromGroup("test","cn=test,ou=Groups,o=testOrg,dc=zty,dc=com");
//print("The Login Url is '$url' .\n");

//print("The name of the user tjadmin:$name.\n");

//printf( $attr[0] );

//print_r($groups[0]);
//print_r($identity[0]);
//print( $isE );
//print_r($firstIdentity);
//print_r($token);
//print( $isU );
//print( $currentUser );
//print( $des );
print($isIn);
//printf($isAdd);
ids_Destory(); 

?>
