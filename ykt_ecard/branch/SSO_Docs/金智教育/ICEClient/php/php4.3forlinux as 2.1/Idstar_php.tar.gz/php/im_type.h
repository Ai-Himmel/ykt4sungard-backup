typedef int bool;

struct _tagIdsGroup {
	char *id;
	char *name;	
};
typedef struct _tagIdsGroup IdsGroup ; 

//���� lah
struct _tagAttrMap{
	char *attrName;
	char **attrValues;
};
typedef struct _tagAttrMap AttrMap;

struct _tagIdsIdentity{
	char *orgName;
	char *figure;
};
typedef struct _tagIdsIdentity  IdsIdentity;

struct _tagIdsSSOToken{
	char * userId;
	char * tokenValue;
};
typedef struct _tagIdsSSOToken IdsSSOToken;

struct _tagIdsAttribute{
		char * name;
		char ** values;
};
typedef struct _tagIdsAttribute IdsAttribute;

