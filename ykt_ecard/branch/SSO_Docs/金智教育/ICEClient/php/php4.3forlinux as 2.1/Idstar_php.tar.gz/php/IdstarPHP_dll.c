/* auto generate by dll_wrap.py Wed Jun 16 13:50:08 2004  */


#include "stdlib.h"
#include "dlfcn.h"

#include "idstar_im.h"

#define SOFILE "/opt/idstar/lib/libIdstar.so"

static void * lib_handler = NULL;

static void* load_library()
{
    lib_handler = dlopen(SOFILE,RTLD_LAZY);
    return lib_handler;
}


static void unload_library()
{
    dlclose( lib_handler );
}

static void* get_function ( char*name)
{
    if( ! lib_handler && !load_library() ) 
        return NULL;
    return  dlsym( lib_handler, name );        
}


//function type

typedef void (*ids_Init_t)(const char * config);
typedef void (*ids_Destory_t)();
typedef void (*ids_FreeString_t)(char *);
typedef void (*ids_FreeStringArray_t)(char **);
typedef void (*ids_FreeGroup_t)(IdsGroup *);
typedef void (*ids_FreeGroupArray_t)(IdsGroup ** );
typedef void (*ids_FreeMap_t)(AttrMap *);
typedef void (*ids_FreeMapArray_t)(AttrMap ** );
typedef void (*ids_FreeIdentity_t)(IdsIdentity *);
typedef void (*ids_FreeIdentityArray_t)(IdsIdentity ** );
typedef void (*ids_FreeSSOToken_t)(IdsSSOToken *);
typedef void (*ids_FreeSSOTokenArray_t)(IdsSSOToken ** );
typedef void (*ids_FreeAttribute_t)(IdsAttribute * g);
typedef char* (*ids_GetUserNameByID_t)(char *);
typedef int (*ids_IsUserExist_t)(char *);
typedef char** (*ids_GetUserAttribute_t)(char * id, char * attr);
typedef int (*ids_CheckPassword_t)(char * id, char* password);
typedef IdsGroup** (*ids_GetUserGroup_t)(char*);
typedef IdsGroup** (*ids_GetGroups_t)();
typedef IdsGroup* (*ids_GetRootGroup_t)();
typedef IdsGroup** (*ids_GetSubGroups_t)(char * );
typedef IdsGroup** (*ids_GetGroupByName_t)(char *);
typedef IdsGroup* (*ids_GetGroupByID_t)(char*);
typedef char** (*ids_GetUserByGroup_t)(char*);
typedef char** (*ids_GetUserNameByGroup_t)(char * );
typedef char* (*ids_GetCurrentUser_t)(char * );
typedef char* (*ids_GetLoginURL_t)();
typedef char* (*ids_GetLogoutURL_t)();
typedef char** (*ids_GetEntryAttribute_t)(char*dn, char*attrName);
typedef AttrMap** (*ids_GetUserAttributes_t)(char* id, char** attrNames);
typedef IdsIdentity** (*ids_GetUserIdentities_t)(char* id);
typedef IdsIdentity*  (*ids_GetUserFirstIdentity_t)(char* id);
typedef IdsSSOToken*  (*ids_CreateSSOToken_t)(char* id, char* password);
typedef bool (*ids_DestroySSOToken_t)(char* tokenValue);
typedef IdsSSOToken*  (*ids_ValidateToken_t)(char* tokenValue);
typedef bool (*ids_UpdateUserAttribute_t)(char* id , char * attrName, char * oldV, char * newV);
typedef IdsGroup** (*ids_GetOrgFirstLevelGroups_t)(char * );
typedef IdsGroup** (*ids_GetOrgAllGroups_t)(char * );
typedef char** (*ids_GetOrgAttribute_t)(char * id, char * attr);
typedef bool (*ids_AddUserAttribute_t)(char * id, IdsAttribute* attr);
typedef bool (*ids_DeleteUserAttribute_t)(char * id, IdsAttribute* attr);
typedef bool (*ids_IsUserInGroup_t)(char * id, IdsGroup* group);
typedef bool (*ids_AddUserToGroup_t)(char * id, IdsGroup* group);
typedef bool (*ids_DeleteUserFromGroup_t)(char * id, IdsGroup* group);
typedef bool (*ids_AddUsersToGroup_t)(char ** id, IdsGroup* group);
typedef bool (*ids_DeleteUsersFromGroup_t)(char ** id, IdsGroup* group);
typedef bool (*ids_AddGroupToContainer_t)(IdsGroup* group,char* container);
typedef bool (*ids_DeleteGroupFromContainer_t)(IdsGroup* group);

//function pointer

ids_Init_t p_ids_Init = NULL;
ids_Destory_t p_ids_Destory = NULL;
ids_FreeString_t p_ids_FreeString = NULL;
ids_FreeStringArray_t p_ids_FreeStringArray = NULL;
ids_FreeGroup_t p_ids_FreeGroup = NULL;
ids_FreeGroupArray_t p_ids_FreeGroupArray = NULL;
ids_FreeMap_t p_ids_FreeMap = NULL;
ids_FreeMapArray_t p_ids_FreeMapArray = NULL;
ids_FreeIdentity_t p_ids_FreeIdentity = NULL;
ids_FreeIdentityArray_t p_ids_FreeIdentityArray = NULL;
ids_FreeSSOToken_t p_ids_FreeSSOToken = NULL;
ids_FreeSSOTokenArray_t p_ids_FreeSSOTokenArray = NULL;
ids_FreeAttribute_t p_ids_FreeAttribute = NULL;
ids_GetUserNameByID_t p_ids_GetUserNameByID = NULL;
ids_IsUserExist_t p_ids_IsUserExist = NULL;
ids_GetUserAttribute_t p_ids_GetUserAttribute = NULL;
ids_CheckPassword_t p_ids_CheckPassword = NULL;
ids_GetUserGroup_t p_ids_GetUserGroup = NULL;
ids_GetGroups_t p_ids_GetGroups = NULL;
ids_GetRootGroup_t p_ids_GetRootGroup = NULL;
ids_GetSubGroups_t p_ids_GetSubGroups = NULL;
ids_GetGroupByName_t p_ids_GetGroupByName = NULL;
ids_GetGroupByID_t p_ids_GetGroupByID = NULL;
ids_GetUserByGroup_t p_ids_GetUserByGroup = NULL;
ids_GetUserNameByGroup_t p_ids_GetUserNameByGroup = NULL;
ids_GetCurrentUser_t p_ids_GetCurrentUser = NULL;
ids_GetLoginURL_t p_ids_GetLoginURL = NULL;
ids_GetLogoutURL_t p_ids_GetLogoutURL = NULL;
ids_GetEntryAttribute_t p_ids_GetEntryAttribute = NULL;
ids_GetUserAttributes_t p_ids_GetUserAttributes = NULL;
ids_GetUserIdentities_t p_ids_GetUserIdentities = NULL;
ids_GetUserFirstIdentity_t p_ids_GetUserFirstIdentity = NULL;
ids_CreateSSOToken_t p_ids_CreateSSOToken = NULL;
ids_DestroySSOToken_t p_ids_DestroySSOToken = NULL;
ids_ValidateToken_t p_ids_ValidateToken = NULL;
ids_UpdateUserAttribute_t p_ids_UpdateUserAttribute = NULL;
ids_GetOrgFirstLevelGroups_t p_ids_GetOrgFirstLevelGroups = NULL;
ids_GetOrgAllGroups_t p_ids_GetOrgAllGroups = NULL;
ids_GetOrgAttribute_t p_ids_GetOrgAttribute = NULL;
ids_AddUserAttribute_t p_ids_AddUserAttribute = NULL;
ids_DeleteUserAttribute_t p_ids_DeleteUserAttribute = NULL;
ids_IsUserInGroup_t p_ids_IsUserInGroup = NULL;
ids_AddUserToGroup_t p_ids_AddUserToGroup = NULL;
ids_DeleteUserFromGroup_t p_ids_DeleteUserFromGroup = NULL;
ids_AddUsersToGroup_t p_ids_AddUsersToGroup = NULL;
ids_DeleteUsersFromGroup_t p_ids_DeleteUsersFromGroup = NULL;
ids_AddGroupToContainer_t p_ids_AddGroupToContainer = NULL;
ids_DeleteGroupFromContainer_t p_ids_DeleteGroupFromContainer = NULL;

// wrap function 



void ids_Init ( const char * config  ) 
{
    if ( ! p_ids_Init ) 
        p_ids_Init = (ids_Init_t) get_function( "ids_Init" );

    if ( p_ids_Init )
        return p_ids_Init( config );
    else
        return (void)NULL;
}        
    


void ids_Destory (  ) 
{
    if ( ! p_ids_Destory ) 
        p_ids_Destory = (ids_Destory_t) get_function( "ids_Destory" );

    if ( p_ids_Destory )
        return p_ids_Destory(  );
    else
        return (void)NULL;
}        
    


void ids_FreeString ( char * arg_0 ) 
{
    if ( ! p_ids_FreeString ) 
        p_ids_FreeString = (ids_FreeString_t) get_function( "ids_FreeString" );

    if ( p_ids_FreeString )
        return p_ids_FreeString( arg_0 );
    else
        return (void)NULL;
}        
    


void ids_FreeStringArray ( char ** arg_0 ) 
{
    if ( ! p_ids_FreeStringArray ) 
        p_ids_FreeStringArray = (ids_FreeStringArray_t) get_function( "ids_FreeStringArray" );

    if ( p_ids_FreeStringArray )
        return p_ids_FreeStringArray( arg_0 );
    else
        return (void)NULL;
}        
    


void ids_FreeGroup ( IdsGroup * arg_0 ) 
{
    if ( ! p_ids_FreeGroup ) 
        p_ids_FreeGroup = (ids_FreeGroup_t) get_function( "ids_FreeGroup" );

    if ( p_ids_FreeGroup )
        return p_ids_FreeGroup( arg_0 );
    else
        return (void)NULL;
}        
    


void ids_FreeGroupArray ( IdsGroup ** arg_0 ) 
{
    if ( ! p_ids_FreeGroupArray ) 
        p_ids_FreeGroupArray = (ids_FreeGroupArray_t) get_function( "ids_FreeGroupArray" );

    if ( p_ids_FreeGroupArray )
        return p_ids_FreeGroupArray( arg_0 );
    else
        return (void)NULL;
}        
    


void ids_FreeMap ( AttrMap * arg_0 ) 
{
    if ( ! p_ids_FreeMap ) 
        p_ids_FreeMap = (ids_FreeMap_t) get_function( "ids_FreeMap" );

    if ( p_ids_FreeMap )
        return p_ids_FreeMap( arg_0 );
    else
        return (void)NULL;
}        
    


void ids_FreeMapArray ( AttrMap ** arg_0 ) 
{
    if ( ! p_ids_FreeMapArray ) 
        p_ids_FreeMapArray = (ids_FreeMapArray_t) get_function( "ids_FreeMapArray" );

    if ( p_ids_FreeMapArray )
        return p_ids_FreeMapArray( arg_0 );
    else
        return (void)NULL;
}        
    


void ids_FreeIdentity ( IdsIdentity * arg_0 ) 
{
    if ( ! p_ids_FreeIdentity ) 
        p_ids_FreeIdentity = (ids_FreeIdentity_t) get_function( "ids_FreeIdentity" );

    if ( p_ids_FreeIdentity )
        return p_ids_FreeIdentity( arg_0 );
    else
        return (void)NULL;
}        
    


void ids_FreeIdentityArray ( IdsIdentity ** arg_0 ) 
{
    if ( ! p_ids_FreeIdentityArray ) 
        p_ids_FreeIdentityArray = (ids_FreeIdentityArray_t) get_function( "ids_FreeIdentityArray" );

    if ( p_ids_FreeIdentityArray )
        return p_ids_FreeIdentityArray( arg_0 );
    else
        return (void)NULL;
}        
    


void ids_FreeSSOToken ( IdsSSOToken * arg_0 ) 
{
    if ( ! p_ids_FreeSSOToken ) 
        p_ids_FreeSSOToken = (ids_FreeSSOToken_t) get_function( "ids_FreeSSOToken" );

    if ( p_ids_FreeSSOToken )
        return p_ids_FreeSSOToken( arg_0 );
    else
        return (void)NULL;
}        
    


void ids_FreeSSOTokenArray ( IdsSSOToken ** arg_0 ) 
{
    if ( ! p_ids_FreeSSOTokenArray ) 
        p_ids_FreeSSOTokenArray = (ids_FreeSSOTokenArray_t) get_function( "ids_FreeSSOTokenArray" );

    if ( p_ids_FreeSSOTokenArray )
        return p_ids_FreeSSOTokenArray( arg_0 );
    else
        return (void)NULL;
}        
    


void ids_FreeAttribute ( IdsAttribute * g ) 
{
    if ( ! p_ids_FreeAttribute ) 
        p_ids_FreeAttribute = (ids_FreeAttribute_t) get_function( "ids_FreeAttribute" );

    if ( p_ids_FreeAttribute )
        return p_ids_FreeAttribute( g );
    else
        return (void)NULL;
}        
    


char* ids_GetUserNameByID ( char * arg_0 ) 
{
    if ( ! p_ids_GetUserNameByID ) 
        p_ids_GetUserNameByID = (ids_GetUserNameByID_t) get_function( "ids_GetUserNameByID" );

    if ( p_ids_GetUserNameByID )
        return p_ids_GetUserNameByID( arg_0 );
    else
        return (char*)NULL;
}        
    


int ids_IsUserExist ( char * arg_0 ) 
{
    if ( ! p_ids_IsUserExist ) 
        p_ids_IsUserExist = (ids_IsUserExist_t) get_function( "ids_IsUserExist" );

    if ( p_ids_IsUserExist )
        return p_ids_IsUserExist( arg_0 );
    else
        return (int)NULL;
}        
    


char** ids_GetUserAttribute ( char * id,char * attr ) 
{
    if ( ! p_ids_GetUserAttribute ) 
        p_ids_GetUserAttribute = (ids_GetUserAttribute_t) get_function( "ids_GetUserAttribute" );

    if ( p_ids_GetUserAttribute )
        return p_ids_GetUserAttribute( id,attr );
    else
        return (char**)NULL;
}        
    


int ids_CheckPassword ( char * id,char* password ) 
{
    if ( ! p_ids_CheckPassword ) 
        p_ids_CheckPassword = (ids_CheckPassword_t) get_function( "ids_CheckPassword" );

    if ( p_ids_CheckPassword )
        return p_ids_CheckPassword( id,password );
    else
        return (int)NULL;
}        
    


IdsGroup** ids_GetUserGroup ( char* arg_0 ) 
{
    if ( ! p_ids_GetUserGroup ) 
        p_ids_GetUserGroup = (ids_GetUserGroup_t) get_function( "ids_GetUserGroup" );

    if ( p_ids_GetUserGroup )
        return p_ids_GetUserGroup( arg_0 );
    else
        return (IdsGroup**)NULL;
}        
    


IdsGroup** ids_GetGroups (  ) 
{
    if ( ! p_ids_GetGroups ) 
        p_ids_GetGroups = (ids_GetGroups_t) get_function( "ids_GetGroups" );

    if ( p_ids_GetGroups )
        return p_ids_GetGroups(  );
    else
        return (IdsGroup**)NULL;
}        
    


IdsGroup* ids_GetRootGroup (  ) 
{
    if ( ! p_ids_GetRootGroup ) 
        p_ids_GetRootGroup = (ids_GetRootGroup_t) get_function( "ids_GetRootGroup" );

    if ( p_ids_GetRootGroup )
        return p_ids_GetRootGroup(  );
    else
        return (IdsGroup*)NULL;
}        
    


IdsGroup** ids_GetSubGroups ( char * arg_0 ) 
{
    if ( ! p_ids_GetSubGroups ) 
        p_ids_GetSubGroups = (ids_GetSubGroups_t) get_function( "ids_GetSubGroups" );

    if ( p_ids_GetSubGroups )
        return p_ids_GetSubGroups( arg_0 );
    else
        return (IdsGroup**)NULL;
}        
    


IdsGroup** ids_GetGroupByName ( char * arg_0 ) 
{
    if ( ! p_ids_GetGroupByName ) 
        p_ids_GetGroupByName = (ids_GetGroupByName_t) get_function( "ids_GetGroupByName" );

    if ( p_ids_GetGroupByName )
        return p_ids_GetGroupByName( arg_0 );
    else
        return (IdsGroup**)NULL;
}        
    


IdsGroup* ids_GetGroupByID ( char* arg_0 ) 
{
    if ( ! p_ids_GetGroupByID ) 
        p_ids_GetGroupByID = (ids_GetGroupByID_t) get_function( "ids_GetGroupByID" );

    if ( p_ids_GetGroupByID )
        return p_ids_GetGroupByID( arg_0 );
    else
        return (IdsGroup*)NULL;
}        
    


char** ids_GetUserByGroup ( char* arg_0 ) 
{
    if ( ! p_ids_GetUserByGroup ) 
        p_ids_GetUserByGroup = (ids_GetUserByGroup_t) get_function( "ids_GetUserByGroup" );

    if ( p_ids_GetUserByGroup )
        return p_ids_GetUserByGroup( arg_0 );
    else
        return (char**)NULL;
}        
    


char** ids_GetUserNameByGroup ( char * arg_0 ) 
{
    if ( ! p_ids_GetUserNameByGroup ) 
        p_ids_GetUserNameByGroup = (ids_GetUserNameByGroup_t) get_function( "ids_GetUserNameByGroup" );

    if ( p_ids_GetUserNameByGroup )
        return p_ids_GetUserNameByGroup( arg_0 );
    else
        return (char**)NULL;
}        
    


char* ids_GetCurrentUser ( char * arg_0 ) 
{
    if ( ! p_ids_GetCurrentUser ) 
        p_ids_GetCurrentUser = (ids_GetCurrentUser_t) get_function( "ids_GetCurrentUser" );

    if ( p_ids_GetCurrentUser )
        return p_ids_GetCurrentUser( arg_0 );
    else
        return (char*)NULL;
}        
    


char* ids_GetLoginURL (  ) 
{
    if ( ! p_ids_GetLoginURL ) 
        p_ids_GetLoginURL = (ids_GetLoginURL_t) get_function( "ids_GetLoginURL" );

    if ( p_ids_GetLoginURL )
        return p_ids_GetLoginURL(  );
    else
        return (char*)NULL;
}        
    


char* ids_GetLogoutURL (  ) 
{
    if ( ! p_ids_GetLogoutURL ) 
        p_ids_GetLogoutURL = (ids_GetLogoutURL_t) get_function( "ids_GetLogoutURL" );

    if ( p_ids_GetLogoutURL )
        return p_ids_GetLogoutURL(  );
    else
        return (char*)NULL;
}        
    


char** ids_GetEntryAttribute ( char*dn,char*attrName ) 
{
    if ( ! p_ids_GetEntryAttribute ) 
        p_ids_GetEntryAttribute = (ids_GetEntryAttribute_t) get_function( "ids_GetEntryAttribute" );

    if ( p_ids_GetEntryAttribute )
        return p_ids_GetEntryAttribute( dn,attrName );
    else
        return (char**)NULL;
}        
    


AttrMap** ids_GetUserAttributes ( char* id,char** attrNames ) 
{
    if ( ! p_ids_GetUserAttributes ) 
        p_ids_GetUserAttributes = (ids_GetUserAttributes_t) get_function( "ids_GetUserAttributes" );

    if ( p_ids_GetUserAttributes )
        return p_ids_GetUserAttributes( id,attrNames );
    else
        return (AttrMap**)NULL;
}        
    


IdsIdentity** ids_GetUserIdentities ( char* id ) 
{
    if ( ! p_ids_GetUserIdentities ) 
        p_ids_GetUserIdentities = (ids_GetUserIdentities_t) get_function( "ids_GetUserIdentities" );

    if ( p_ids_GetUserIdentities )
        return p_ids_GetUserIdentities( id );
    else
        return (IdsIdentity**)NULL;
}        
    


IdsIdentity*  ids_GetUserFirstIdentity ( char* id ) 
{
    if ( ! p_ids_GetUserFirstIdentity ) 
        p_ids_GetUserFirstIdentity = (ids_GetUserFirstIdentity_t) get_function( "ids_GetUserFirstIdentity" );

    if ( p_ids_GetUserFirstIdentity )
        return p_ids_GetUserFirstIdentity( id );
    else
        return (IdsIdentity* )NULL;
}        
    


IdsSSOToken*  ids_CreateSSOToken ( char* id,char* password ) 
{
    if ( ! p_ids_CreateSSOToken ) 
        p_ids_CreateSSOToken = (ids_CreateSSOToken_t) get_function( "ids_CreateSSOToken" );

    if ( p_ids_CreateSSOToken )
        return p_ids_CreateSSOToken( id,password );
    else
        return (IdsSSOToken* )NULL;
}        
    


bool ids_DestroySSOToken ( char* tokenValue ) 
{
    if ( ! p_ids_DestroySSOToken ) 
        p_ids_DestroySSOToken = (ids_DestroySSOToken_t) get_function( "ids_DestroySSOToken" );

    if ( p_ids_DestroySSOToken )
        return p_ids_DestroySSOToken( tokenValue );
    else
        return (bool)NULL;
}        
    


IdsSSOToken*  ids_ValidateToken ( char* tokenValue ) 
{
    if ( ! p_ids_ValidateToken ) 
        p_ids_ValidateToken = (ids_ValidateToken_t) get_function( "ids_ValidateToken" );

    if ( p_ids_ValidateToken )
        return p_ids_ValidateToken( tokenValue );
    else
        return (IdsSSOToken* )NULL;
}        
    


bool ids_UpdateUserAttribute ( char* id,char * attrName,char * oldV,char * newV ) 
{
    if ( ! p_ids_UpdateUserAttribute ) 
        p_ids_UpdateUserAttribute = (ids_UpdateUserAttribute_t) get_function( "ids_UpdateUserAttribute" );

    if ( p_ids_UpdateUserAttribute )
        return p_ids_UpdateUserAttribute( id,attrName,oldV,newV );
    else
        return (bool)NULL;
}        
    


IdsGroup** ids_GetOrgFirstLevelGroups ( char * arg_0 ) 
{
    if ( ! p_ids_GetOrgFirstLevelGroups ) 
        p_ids_GetOrgFirstLevelGroups = (ids_GetOrgFirstLevelGroups_t) get_function( "ids_GetOrgFirstLevelGroups" );

    if ( p_ids_GetOrgFirstLevelGroups )
        return p_ids_GetOrgFirstLevelGroups( arg_0 );
    else
        return (IdsGroup**)NULL;
}        
    


IdsGroup** ids_GetOrgAllGroups ( char * arg_0 ) 
{
    if ( ! p_ids_GetOrgAllGroups ) 
        p_ids_GetOrgAllGroups = (ids_GetOrgAllGroups_t) get_function( "ids_GetOrgAllGroups" );

    if ( p_ids_GetOrgAllGroups )
        return p_ids_GetOrgAllGroups( arg_0 );
    else
        return (IdsGroup**)NULL;
}        
    


char** ids_GetOrgAttribute ( char * id,char * attr ) 
{
    if ( ! p_ids_GetOrgAttribute ) 
        p_ids_GetOrgAttribute = (ids_GetOrgAttribute_t) get_function( "ids_GetOrgAttribute" );

    if ( p_ids_GetOrgAttribute )
        return p_ids_GetOrgAttribute( id,attr );
    else
        return (char**)NULL;
}        
    


bool ids_AddUserAttribute ( char * id,IdsAttribute* attr ) 
{
    if ( ! p_ids_AddUserAttribute ) 
        p_ids_AddUserAttribute = (ids_AddUserAttribute_t) get_function( "ids_AddUserAttribute" );

    if ( p_ids_AddUserAttribute )
        return p_ids_AddUserAttribute( id,attr );
    else
        return (bool)NULL;
}        
    


bool ids_DeleteUserAttribute ( char * id,IdsAttribute* attr ) 
{
    if ( ! p_ids_DeleteUserAttribute ) 
        p_ids_DeleteUserAttribute = (ids_DeleteUserAttribute_t) get_function( "ids_DeleteUserAttribute" );

    if ( p_ids_DeleteUserAttribute )
        return p_ids_DeleteUserAttribute( id,attr );
    else
        return (bool)NULL;
}        
    


bool ids_IsUserInGroup ( char * id,IdsGroup* group ) 
{
    if ( ! p_ids_IsUserInGroup ) 
        p_ids_IsUserInGroup = (ids_IsUserInGroup_t) get_function( "ids_IsUserInGroup" );

    if ( p_ids_IsUserInGroup )
        return p_ids_IsUserInGroup( id,group );
    else
        return (bool)NULL;
}        
    


bool ids_AddUserToGroup ( char * id,IdsGroup* group ) 
{
    if ( ! p_ids_AddUserToGroup ) 
        p_ids_AddUserToGroup = (ids_AddUserToGroup_t) get_function( "ids_AddUserToGroup" );

    if ( p_ids_AddUserToGroup )
        return p_ids_AddUserToGroup( id,group );
    else
        return (bool)NULL;
}        
    


bool ids_DeleteUserFromGroup ( char * id,IdsGroup* group ) 
{
    if ( ! p_ids_DeleteUserFromGroup ) 
        p_ids_DeleteUserFromGroup = (ids_DeleteUserFromGroup_t) get_function( "ids_DeleteUserFromGroup" );

    if ( p_ids_DeleteUserFromGroup )
        return p_ids_DeleteUserFromGroup( id,group );
    else
        return (bool)NULL;
}        
    


bool ids_AddUsersToGroup ( char ** id,IdsGroup* group ) 
{
    if ( ! p_ids_AddUsersToGroup ) 
        p_ids_AddUsersToGroup = (ids_AddUsersToGroup_t) get_function( "ids_AddUsersToGroup" );

    if ( p_ids_AddUsersToGroup )
        return p_ids_AddUsersToGroup( id,group );
    else
        return (bool)NULL;
}        
    


bool ids_DeleteUsersFromGroup ( char ** id,IdsGroup* group ) 
{
    if ( ! p_ids_DeleteUsersFromGroup ) 
        p_ids_DeleteUsersFromGroup = (ids_DeleteUsersFromGroup_t) get_function( "ids_DeleteUsersFromGroup" );

    if ( p_ids_DeleteUsersFromGroup )
        return p_ids_DeleteUsersFromGroup( id,group );
    else
        return (bool)NULL;
}        
    


bool ids_AddGroupToContainer ( IdsGroup* group,char* container ) 
{
    if ( ! p_ids_AddGroupToContainer ) 
        p_ids_AddGroupToContainer = (ids_AddGroupToContainer_t) get_function( "ids_AddGroupToContainer" );

    if ( p_ids_AddGroupToContainer )
        return p_ids_AddGroupToContainer( group,container );
    else
        return (bool)NULL;
}        
    


bool ids_DeleteGroupFromContainer ( IdsGroup* group ) 
{
    if ( ! p_ids_DeleteGroupFromContainer ) 
        p_ids_DeleteGroupFromContainer = (ids_DeleteGroupFromContainer_t) get_function( "ids_DeleteGroupFromContainer" );

    if ( p_ids_DeleteGroupFromContainer )
        return p_ids_DeleteGroupFromContainer( group );
    else
        return (bool)NULL;
}        
    
