/* auto generate by dll_wrap.py Tue Jun 15 13:44:31 2004  */

// wrap function 

void ids_Init(  );

void ids_Destory(  );

void ids_FreeString( char * arg_0 );

void ids_FreeStringArray( char ** arg_0 );

void ids_FreeGroup( IdsGroup * arg_0 );

void ids_FreeGroupArray( IdsGroup ** arg_0 );

void ids_FreeMap( AttrMap * arg_0 );

void ids_FreeMapArray( AttrMap ** arg_0 );

void ids_FreeIdentity( IdsIdentity * arg_0 );

void ids_FreeIdentityArray( IdsIdentity ** arg_0 );

void ids_FreeSSOToken( IdsSSOToken * arg_0 );

void ids_FreeSSOTokenArray( IdsSSOToken ** arg_0 );

void ids_FreeAttribute( IdsAttribute * g );

char* ids_GetUserNameByID( char * arg_0 );

int ids_IsUserExist( char * arg_0 );

char** ids_GetUserAttribute( char * id,char * attr );

int ids_CheckPassword( char * id,char* password );

IdsGroup** ids_GetUserGroup( char* arg_0 );

IdsGroup** ids_GetGroups(  );

IdsGroup* ids_GetRootGroup(  );

IdsGroup** ids_GetSubGroups( char * arg_0 );

IdsGroup** ids_GetGroupByName( char * arg_0 );

IdsGroup* ids_GetGroupByID( char* arg_0 );

char** ids_GetUserByGroup( char* arg_0 );

char** ids_GetUserNameByGroup( char * arg_0 );

char* ids_GetCurrentUser( char * arg_0 );

char* ids_GetLoginURL(  );

char* ids_GetLogoutURL(  );

char** ids_GetEntryAttribute( char*dn,char*attrName );

AttrMap** ids_GetUserAttributes( char* id,char** attrNames );

IdsIdentity** ids_GetUserIdentities( char* id );

IdsIdentity*  ids_GetUserFirstIdentity( char* id );

IdsSSOToken*  ids_CreateSSOToken( char* id,char* password );

bool ids_DestroySSOToken( char* tokenValue );

IdsSSOToken*  ids_ValidateToken( char* tokenValue );

bool ids_UpdateUserAttribute( char* id,char * attrName,char * oldV,char * newV );

IdsGroup** ids_GetOrgFirstLevelGroups( char * arg_0 );

IdsGroup** ids_GetOrgAllGroups( char * arg_0 );

char** ids_GetOrgAttribute( char * id,char * attr );

bool ids_AddUserAttribute( char * id,IdsAttribute* attr );

bool ids_DeleteUserAttribute( char * id,IdsAttribute* attr );

bool ids_IsUserInGroup( char * id,IdsGroup* group );

bool ids_AddUserToGroup( char * id,IdsGroup* group );

bool ids_DeleteUserFromGroup( char * id,IdsGroup* group );

bool ids_AddUsersToGroup( char ** id,IdsGroup* group );

bool ids_DeleteUsersFromGroup( char ** id,IdsGroup* group );

bool ids_AddGroupToContainer( IdsGroup* group,char* container );

bool ids_DeleteGroupFromContainer( IdsGroup* group );

