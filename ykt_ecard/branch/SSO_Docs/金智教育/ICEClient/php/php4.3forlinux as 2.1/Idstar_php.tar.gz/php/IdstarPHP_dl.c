#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "idstar_im.h"

/*******************************************************
RedHat 7.2 ����һ��BUG����̬���� libIdstar.so ��PHP�����˳���ʱ�򣬻���ִ���
����ʹ�� ��̬���ؿ��Ա������ִ���
*******************************************************/


IdsGroup getIdsGroup(char * id,char * name)
{
	IdsGroup idsGroup;
	idsGroup.id = id;
	idsGroup.name = name;
	return idsGroup;
}
bool isUserInGroup(char * id,char * groupId)
{
	IdsGroup idsGroup;
	idsGroup = getIdsGroup(groupId,"");
	return ids_IsUserInGroup(id,&idsGroup);
}
bool addUserAttribute(char * id, char* attrName, char* attrValue)
{
	IdsAttribute attr;
	char* attrVs[2];
	attrVs[0] = attrValue;
	attrVs[1] = 0;
	attr.name = attrName;
	attr.values = attrVs;
	return ids_AddUserAttribute(id,&attr);
}
bool deleteUserAttribute(char * id, char* attrName, char* attrValue)
{                                             
        IdsAttribute attr;                    
        char * attrVs[2];
	attrVs[0] = attrValue;
	attrVs[1] = 0;
	attr.name = attrName;
	attr.values = attrVs;
	return ids_DeleteUserAttribute(id,&attr);
}

bool addUserToGroup(char* userId,char* groupDN)
{
	IdsGroup group;
	group = getIdsGroup(groupDN,"");
	return ids_AddUserToGroup(userId,&group);
}

bool deleteUserFromGroup(char * userId,char * groupDN)
{
	IdsGroup group;
	group = getIdsGroup(groupDN,"");
	return ids_DeleteUserFromGroup(userId,&group);
}
bool addGroupToContainer(char * groupName,char * containerDN)
{
	IdsGroup group;
	group = getIdsGroup("",groupName);
	return ids_AddGroupToContainer(&group,containerDN);
}
bool deleteGroupFromContainer(char* groupDN)
{
	IdsGroup group;
	group = getIdsGroup(groupDN,"");
	return ids_DeleteGroupFromContainer(&group);
}
