#!/bin/sh

/opt/php4/bin/php -f getloginurl.php 
