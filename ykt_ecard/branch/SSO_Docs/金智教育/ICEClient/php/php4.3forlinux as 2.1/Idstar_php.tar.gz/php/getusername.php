<?php
#dl("libIdstarPhp.so");
#ids_Init("../etc/client.properties");

$name = ids_GetUserNameByID("amadmin");
print $name;
for ( $i=0 ; $i<100; $i++)
    $name = ids_GetLoginURL();
print $name;

#ids_Destory(); 

?>
