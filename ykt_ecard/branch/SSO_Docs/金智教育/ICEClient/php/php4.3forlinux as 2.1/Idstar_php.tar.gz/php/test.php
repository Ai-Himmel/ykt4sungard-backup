<?php
$cookies = $_COOKIE['iPlanetDirectoryPro'];
if ( $cookies )
{
	print("ok");
}
else 
{
	print("fail");
}
?>
