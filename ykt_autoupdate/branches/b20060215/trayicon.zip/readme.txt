This zip-file contains the two Delphi components, CoolTrayIcon and
TextTrayIcon (tray icon components).

Refer to CoolTrayIcon.chm and install.txt for documentation.

See also convert_cti_projects.txt if you're upgrading from a previous version
of CoolTrayIcon/TextTrayIcon.

***** If you redistribute this package, please include all original files. *****

