//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TestGWDemo.rc
//
#define ID_BTN_COM                      3
#define ID_READ_BALANCE                 4
#define ID_READ_CARDINFO                5
#define ID_READ_CUTINFO                 6
#define ID_INIT_COMM                    7
#define ID_EXIT                         8
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTDEMO_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_COM_PORT                    1000
#define IDC_EDIT1                       1001
#define IDC_COM_BAND                    1002
#define IDC_LOAD_KEY                    1003
#define IDC_EDIT3                       1004
#define IDC_BUTTON2                     1005
#define IDC_READ_AUTHCARD               1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
