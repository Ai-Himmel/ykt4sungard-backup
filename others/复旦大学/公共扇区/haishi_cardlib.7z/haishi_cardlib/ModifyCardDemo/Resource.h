//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ModifyCardDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MODIFYCARDDEMO_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDC_COM_PORT                    1000
#define IDC_COM_BAND                    1001
#define IDC_BTN_COM                     1002
#define IDC_BTN_AUTH                    1003
#define IDC_CMB_KEY                     1004
#define IDC_MANUAL_AUTH                 1005
#define IDC_BTN_MODIFY_CARDID           1006
#define IDC_EDIT_CARDID                 1007
#define IDC_BTN_MODIFY_SHOWID           1008
#define IDC_EDIT_SHOW_CARDID            1009
#define IDC_BTN_SHOW_CARD_INFO          1010
#define IDC_BTN_MODIFY_SEPNO            1011
#define IDC_BTN_SHOW_SEPNO              1012
#define IDC_BTN_INIT_AUTH_CARD          1012
#define IDC_EDIT_SEPNO                  1013
#define IDC_BTN_RESET_AUTH_CARD         1014
#define IDC_EDIT_WORK_KEY               1015
#define IDC_EDIT_AUTH_CARD_FLAG         1016
#define IDC_BTN_READ_AUTH_CARD          1017
#define IDC_EDIT_PWD                    1018
#define IDC_EDIT_CUTTYPE                1019
#define IDC_EDIT_SEX                    1020
#define IDC_BTN_MODIFY_PWD              1021
#define IDC_BTN_MODIFY_CUTTYPE          1022
#define IDC_BTN_MODIFY_SEX              1023
#define IDC_BTN_REFINE_SECTOR           1024
#define IDC_CMB_KEY2                    1025
#define IDC_CMB_SECTOR                  1025
#define IDC_BTN_MODIFY_BALANCE          1026
#define IDC_EDIT_SEX2                   1027
#define IDC_EDIT_MONEY                  1027
#define IDC_EDIT_CNT                    1028
#define IDC_BTN_MODIFY_CNT              1029
#define IDC_BTN_MODIFY_DEADDATE         1030
#define IDC_EDIT_DEAD_DATE              1031
#define IDC_BTN_MODIFY_DONGHUA          1032
#define IDC_EDIT_WORK_KEY2              1033
#define IDC_EDIT_PERSONAL_ID            1033
#define IDC_BTN_REFINE_SECTOR2          1034
#define IDC_BTN_MODIFY_PUB_SECT         1034
#define IDC_UPD_INFO                    1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
