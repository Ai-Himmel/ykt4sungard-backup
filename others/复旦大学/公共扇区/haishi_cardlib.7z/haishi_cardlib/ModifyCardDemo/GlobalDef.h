#ifndef _GLOBAL_DEFINE_H_
#define _GLOBAL_DEFINE_H_

#include "ExceptionErr.h"

#include "carddll_def.h"

#ifdef __cplusplus
extern "C" {
#endif

extern CExceptionErr err_exce;

#ifdef __cplusplus
}
#endif

#endif