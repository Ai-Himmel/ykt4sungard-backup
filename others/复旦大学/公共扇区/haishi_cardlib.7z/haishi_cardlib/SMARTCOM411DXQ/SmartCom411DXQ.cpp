/***************************************************************************************************/
/* ����........ʵ�ֶԻ��Ӳ���Ĳ���                                                                   
/* ����........�򿪴���, ������Կ, ��ȡ���ݣ�д������(�ڼ�������, �ڼ���), ����, �رմ���, ������Ϣ                                                            */
/* ����........����
/* ����........2006/13/07
/***************************************************************************************************/

#include "stdafx.h"
#include "stdlib.h"
#include "Comm.h"

#pragma  pack(1)
typedef struct _LOOPPURSEINFO
{
		DWORD RemainMoney;// ����Ǯ�����
		WORD DealTimes;// ��Ƭ������ˮ��
		BYTE DealYear; //��������
		BYTE DealMonth; 
		BYTE DealDay;
		BYTE DealHour;
		BYTE DealMin;
		BYTE DealTimes_CurTime; // �ۼƽ��״���(��ǰʱ�����)
		BYTE DealTimes_CurDay;// �ۼƽ��״���(������)
} LOOPPURSEINFO,*LPLOOPPURSEINFO;

typedef struct 
{
	int bala;
	int daybala;
	int total_cnt;
	int day_cnt;
	int time_cnt;
	int date;	//yyyymmdd
	int time;	//hhmmss
}MONEY_PACK_INFO;

typedef struct
{
	char cardtype;
	int termid;
	int remain;
	BYTE oldSerialNo[4];
}WATER_PACK_INFO;

#define WATER_AUTH_CARD 1
#define WATER_COMMON_CARD 2
#define WATER_CLEAR_CARD 3
#define WATER_NEW_CARD 4
#define WATER_FIXED_CARD 5

#pragma  pack()

static unsigned char s_water_common_card[2] = {0xF9,0x9E};
static unsigned char s_water_clear_card[2] = {0xF9,0x9C};
static unsigned char s_water_new_card[2] = {0xF9,0x9D};
static unsigned char s_water_auth_card[2] = {0xF9,0x9F};

static struct version_info 
{
	char ks_ver_no[20];
	char ks_ver_dcb[80];
}version_info = {"v1.0.0.0", "���Ŷ�������̬��"};

//��Ȩ��־
int nAutoFlag = 0;
unsigned char UCWORKINGKEY[256]="";
char g_ErrMsg[1024]="";
int g_ErrCode=-1;

void dec2hex(unsigned char *sDec,int dec_len,char *sHex)
{
	int i=0;
    int k=0;
	for(i=0;i<dec_len;i++)
	{
        k=sDec[i];
        sprintf(&sHex[2*i],"%02X",k);
	}
}
void hex2dec(char *sHex,unsigned char * sDec,int dec_len)
{
	int i=0;
	unsigned long ul;
	char sHexTmp[3];

	memset(sHexTmp,0,sizeof(sHexTmp));
	for(i=0;i<dec_len;i++)
	{
		memcpy(sHexTmp,&sHex[2*i],2);
		ul=strtoul(sHexTmp,NULL,16);
		sDec[i]=(unsigned char)ul;
	}
}
int dec2bcd(unsigned char *sDecStr,unsigned char *sBcdStr,int bcd_len)
{
	int i;
	unsigned char lch,hch;

	for(i=0;i<bcd_len;i++)
	{
		lch=sDecStr[2*i]-'0';
		hch=sDecStr[2*i+1]-'0';
		lch=lch<<4;
		hch=hch&0x0F;
		lch=lch&0xF0;
		sBcdStr[i]=hch|lch;
	}
	return 0;
}
int  bcd2dec(unsigned char *sBcdStr,int bcd_len,char *sDecStr)
{	
	int i;
	unsigned char lch,hch;

	for(i=0;i<bcd_len;i++)
	{
		hch=(sBcdStr[i]&0x0F);
		lch=(sBcdStr[i]&0xF0);
		lch=lch>>4;
		sDecStr[2*i]=lch+'0';
		sDecStr[2*i+1]=hch+'0';
	}
	return 0;
}

//���ô�����Ϣ
void _stdcall SetLastErrMsg(int err_code,char* format, ...)
{
	 va_list arglist; 
	 char buffer[1024]=""; 
	 va_start (arglist,format); 
	 vsprintf(buffer, format, arglist); 
	 va_end (arglist); 
	 strcpy(g_ErrMsg,buffer);
	 g_ErrCode=err_code;
}
//ȡ������Ϣ
void _stdcall SMT_GetLastErr(int* pErrCode,char *Msg)
{
	*pErrCode=g_ErrCode;
	strcpy(Msg,g_ErrMsg);
}

//*************��ȡ������뺯��*********************
int _stdcall GetMFLastErr()
{
	return ErrorCode;
}

//*******************************************
int Init_SetParam(char *ComStr,int MachineNo,int BaudRate)
{
    Dll_bps=BaudRate;                                    //������
    Dll_MacNo =MachineNo;                                //����
	ErrorCode = 0;

// ��ʼ������
	if(CommIntilialize(ComStr,Dll_bps) != 0)
		return(-1);
	
	return 0;
}

//***********************************************
// �رմ��ھ��
int CloseComHandle()
{
	if(hCommDev)
	{
		CloseHandle(hCommDev);
	}
	return 0;
}
//**public command*****************************************
int ReadTermID(unsigned char *IDBuf,BOOL bLinked,char *ComStr,int BaudRate)
{
	int retCode,Len;

	Dll_MacNo = 0xff;
	Dll_CommByte = 0xe1;

	if(!bLinked)
	{
		if(Init_SetParam(ComStr,Dll_MacNo,BaudRate) < 0)
			return(-1);
	}

	Dll_MacNo = 0xff;
	Dll_CommByte = 0xe1;
	retCode = ExeCommand(IDBuf,0);
	if(retCode<0)
	{
		if(!bLinked)
			CloseComHandle();
		return retCode;
	}

	if(!bLinked)
		CloseComHandle();
	Len = Dll_RetData[3];
	memcpy(IDBuf,Dll_RetData+4,Len);
	Dll_MacNo = Dll_RetData[Len+3];
	return Dll_MacNo;
}
//**public command*****************************************
int QueryTermID(unsigned char LowIDNo,unsigned char *Buffer,BOOL bLinked,char *ComStr,int BaudRate)
{
	int retCode,Len;

	Dll_MacNo = 0xff;
	Dll_CommByte = 0xe2;

	if(!bLinked)
	{
		if(Init_SetParam(ComStr,Dll_MacNo,BaudRate) < 0)
			return(-1);
	}

	Dll_MacNo = 0xff;
	Dll_CommByte = 0xe2;
	Buffer[0] = LowIDNo;
	retCode = ExeCommand(Buffer,1);
	if(retCode<0)
	{
		if(!bLinked)
			CloseComHandle();
		return retCode;
	}

	if(!bLinked)
		CloseComHandle();
	Len = Dll_RetData[3];

	memcpy(Buffer,Dll_RetData+4,Len);

	Dll_MacNo = Dll_RetData[8];
	return Dll_MacNo;
}
//**public command*****************************************
int SetTermMacNo(unsigned char *IDBuf,int MacNo,BOOL bLinked,char *ComStr,int BaudRate)
{
	int retCode,Len;
	BYTE Buffer[8];

	Dll_MacNo = 0xff;
	Dll_CommByte = 0xe3;

	if((MacNo>255)||(MacNo<1))
	{
		ErrorCode = 31;
		return (-1);
	}
	if(!bLinked)
	{
		if(Init_SetParam(ComStr,Dll_MacNo,BaudRate) < 0)
			return(-1);
	}

	Dll_MacNo = 0xff;
	Dll_CommByte = 0xe3;

	Len = 4;
	memcpy(Buffer,IDBuf,4);
	Buffer[4] = MacNo;

	retCode = ExeCommand(Buffer,5);
	if(retCode<0)
	{
		if(!bLinked)
			CloseComHandle();
		return retCode;
	}

	if(!bLinked)
		CloseComHandle();
	Dll_MacNo = MacNo;
	return Dll_MacNo;
}
//**public command*****************************************
int ReadTermMacType(unsigned char *Buffer,BOOL bLinked,char *ComStr,int BaudRate)
{
	int retCode,Len;

	Dll_CommByte = 0xe4;

	if(!bLinked)
	{
	// ��ʼ������
		Dll_MacNo = 0xff;
		if(Init_SetParam(ComStr,Dll_MacNo,BaudRate) < 0)
			return(-1);
	}

	Dll_CommByte = 0xe4;
	retCode = ExeCommand(Buffer,0);
	if(retCode<0)
	{
		if(!bLinked)
			CloseComHandle();
		return retCode;
	}

	if(!bLinked)
		CloseComHandle();
	Len = Dll_RetData[3];

	memcpy(Buffer,Dll_RetData+4,Len);

	return Len;
}
//**public command*****************************************
int ReadTermDate(unsigned char *Buffer,BOOL bLinked,char *ComStr,int BaudRate)
{
	int retCode,Len;

	if(!bLinked)
	{
	// ��ʼ������
		Dll_MacNo = 0xff;
		if(Init_SetParam(ComStr,Dll_MacNo,BaudRate) < 0)
			return(-1);
	}

	Dll_CommByte = 0xe5;
	retCode = ExeCommand(Buffer,0);
	if(retCode<0)
	{
		if(!bLinked)
			CloseComHandle();
		return retCode;
	}

	if(!bLinked)
		CloseComHandle();
	Len = Dll_RetData[3];
	memcpy(Buffer,Dll_RetData+4,Len);
	return Len;
}

//��д������
int _stdcall SMT_ConnectMF280(int nPortNo, int nBaudRate)
{
	char tmp[20];
	unsigned char IDBuf[16];
	int ret;
	int macno=1;
	sprintf(tmp,"\\\\?\\COM%d",nPortNo);
	if(ReadTermMacType(IDBuf,false,tmp,nBaudRate)<0)
	{
		return -1;
	}
	if(IDBuf[0]!=4||IDBuf[1]!=20)
	{
		return -1;
	}
	Sleep(10);
	memset(IDBuf,0,16);
	ret = ReadTermID(IDBuf,false,tmp,nBaudRate);
	if(ret<0)
		return -1;
	macno=ret;
	if(Init_SetParam(tmp,macno,nBaudRate)<0)
	{
		return -1;
	}
	nAutoFlag=0;
	return 0;
}

//2���ض϶�д��
int _stdcall SMT_CloseMF280()
{
	int ret;
	ret = CloseComHandle();
	return ret;
}

//3����д������������
int _stdcall SMT_ControlBuzzer()
{
	int retCode;
	BYTE Buffer[1];

	Dll_CommByte = 59;

	Buffer[0]=NULL;
	retCode = ExeCommand(Buffer,0);
	if(retCode<0)
		return retCode;
	return 0;
}

//*******************************************
int _stdcall MF_ReadSeriesNo(unsigned char *Buffer)                    // �����޸Ĺ�_stdcall
{
	int retCode,Len;

	Dll_CommByte = 1;
	Len = 0;
	retCode = ExeCommand(Buffer,Len);
	if(retCode<0)
		return retCode;

	Len = Dll_RetData[3];
	memcpy(Buffer,Dll_RetData+4,Len);
//	Buffer[Len] = NULL;
	if (Len == 0)
	{
		return -1;
	}
	return Len;
}


//1������û����Ƿ��ڸ�Ӧ��
int _stdcall SMT_RequestCardExist(unsigned char ucSerialNo[4],unsigned char ucType[1])
{
	unsigned char Buf[5];
	int ret;
	ret = MF_ReadSeriesNo(Buf);
	if(ret > 0)
	{
		memcpy(ucSerialNo,Buf,4);
		memcpy(ucType,Buf+4,1);
		return 0;
	}
	return -1;
}

//2����½��Ƭ 
int _stdcall SMT_Login_With_UserKey(int Sector,unsigned char *Buffer,int PaDSelect)
// Sector ������
// PaDSelect == 0 KEYA ��½
// PaDSelect == 1 KEYB ��½
// Buffer -----KEYA��KEYB

{
	int retCode,Len;
	
	unsigned char Buffer_temp[20];
	memset(Buffer_temp,0,20);

	Dll_CommByte = 16;  
	
	Buffer_temp[0] = Sector;
	if(PaDSelect == 0)
	{
		Buffer_temp[1] = 0x02;//AKEY��¼
		memcpy(Buffer_temp+2,Buffer,6);
	}
	else
	{
		Buffer_temp[1] = 0x42;//BKEY��¼
		memcpy(Buffer_temp+2+6,Buffer,6);
	}
	Len = 14;
	retCode = ExeCommand(Buffer_temp,Len);
	return retCode;
}

//3������Ƭ
int _stdcall SMT_ReadBlock(int Sector,int BlockNo, unsigned char *BlockBuf)
{
	int retCode,i,Len;
	BlockBuf[0] = Sector;
	BlockBuf[1] = BlockNo;
	Len = 2;
	Dll_CommByte = 0x2C;  
	retCode = ExeCommand(BlockBuf,Len);
	if(retCode<0)
		return retCode;

	Len = Dll_RetData[3];
	for(i = 0;i<Len;i++)
		BlockBuf[i] = Dll_RetData[i+4];
	return retCode;
}

//4��д��Ƭ
int _stdcall SMT_WriteBlock(int Sector,int BlockNo,unsigned char *BlockBuf)
{
	unsigned char Buf[20];
	int retCode,i,Len;

	
	Dll_CommByte = 0x2D; 
	Len = 16;
	memset(Buf,0,20);
	Buf[0] = Sector;
	Buf[1] = BlockNo;

	for(i = 0;i < Len;i++)
		Buf[2+i] = BlockBuf[i];

	retCode = ExeCommand(Buf,Len+2);
	if(retCode<0)
		return retCode;

	Len = Dll_RetData[3];
	
	for(i = 0;i<Len;i++)
		BlockBuf[i] = Dll_RetData[i+4];
	return retCode;

}

//5����Ǯ
int _stdcall SMT_Philips_Packet_Proc(int flag,int Sector,int BlockNo,int Money,unsigned char *BlockBuf)
//flag���Ӽ�Ǯ��־ 0---�� 1---��
{
	unsigned char Buf[20];
	int retCode,Len;

	if(flag == 0)
		Dll_CommByte = 0x2e; 
	else
		Dll_CommByte = 0x2f;
	Len = 6;
	memset(Buf,0,20);
	Buf[0] = Sector;
	Buf[1] = BlockNo;
	Buf[2] = Money%256;
	Buf[3] = Money/256;
	Buf[4] = Money/256/256;
	Buf[5] = Money/256/256/256;
	
	retCode = ExeCommand(Buf,Len);
	if(retCode<0)
		return retCode;

	Len = Dll_RetData[3];
	for(int i = 0;i<Len;i++)
		BlockBuf[i] = Dll_RetData[i+4];
	return retCode;
}

//6 ���ݿ�COPY
int _stdcall SMT_Copy_DataBlock(int Sector,int souBlock,int desBlock,unsigned char *BlockBuf)
{
	unsigned char Buf[20];
	int i,retCode,Len;

	Dll_CommByte = 0x30; 
	Len = 3;
	memset(Buf,0,20);
	Buf[0] = Sector;
	Buf[1] = souBlock;
	Buf[2] = desBlock;
	
	retCode = ExeCommand(Buf,Len);
	if(retCode<0)
		return retCode;

	Len = Dll_RetData[3];
	for(i = 0;i<Len;i++)
		BlockBuf[i] = Dll_RetData[i+4];
	return retCode;
}

//7 ���߿�Ƭ
int _stdcall SMT_SleepCard()
{
	unsigned char Buf[20];
	int retCode,Len;

	Dll_CommByte = 0x08; 
	Len = 0;
	memset(Buf,0,20);
	
	retCode = ExeCommand(Buf,Len);
	return retCode;
}

int _stdcall SMT_GetDllVersion(char *ks_ver_no, char *ks_ver_dcb)
{
	if (strlen(strcpy(ks_ver_no, version_info.ks_ver_no)) == 0)
		return -1;
	
	if (strlen(strcpy(ks_ver_dcb, version_info.ks_ver_dcb)) == 0)
		return -1;
	
	return 0;
}

