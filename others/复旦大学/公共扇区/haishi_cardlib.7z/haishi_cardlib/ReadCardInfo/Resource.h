//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ReadCardInfo.rc
//
#define ID_BTN_TEST                     4
#define ID_CANCEL                       5
#define ID_PAUSEL                       5
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_READCARDINFO_DIALOG         102
#define IDS_TRAY_ICON_HIDE              102
#define IDS_TRAY_ICON_SHOW              103
#define IDS_APP_TITLE                   104
#define IDR_MAINFRAME                   128
#define IDR_POPUP_MENU                  130
#define IDI_ICON1                       131
#define IDI_ICON2                       137
#define IDC_COM_PORT                    1000
#define IDC_COM_BAUDRATE                1001
#define ID_BTN_CONNECT                  1005
#define ID_BTN_CONCANCEL                1006
#define IDC_STATUS                      1007
#define ID_BTN_READ_AUTHORCARD          1012
#define ID_BTN_RECPASSWORD              1013
#define ID_MENUITEM_SHOW                32771
#define ID_MENUITEM_CANCEL              32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
