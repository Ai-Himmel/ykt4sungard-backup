/*
 * IRS Skin Library
 * Designed by Kilo(110i@110i.net)
 * (C)CopyRight, 2003-2004, IRS, All Right Reserved
 * iRacer.Studio - HttP://wWw.110i.nEt
 */
#ifndef _LIBRARY_HEADER
#define _LIBRARY_HEADER

BOOL	IRStartup( HINSTANCE hModule, DWORD dwThreadID );
BOOL	IRComplete( void );

#endif