#!/usr/python
# -*- coding: utf-8 -*-
import os,sys,socket,time,getopt,datetime
import fileinput,codecs,struct,threading
from calcmac2 import CalcMac

def GetReportFileName():
    now_time = datetime.datetime.now()
    fname = now_time.strftime('%Y%m%d%H%M%S')
    fname = 'report_' + fname + '.txt'
    return fname
    
class TestServer(threading.Thread):
    ReportFile=GetReportFileName()
    def __init__(self,endpoint,data_check,run_count=1):
        threading.Thread.__init__(self)
        self.endpoint = endpoint
        self.data_check = data_check
        self.run_count = run_count
        self.sock = None
        self.connected = False
        self.report = 'runreport.txt'
        
    def _closeSocket(self):
        if self.sock:
            self.sock.close()
            self.sock = None
            
        self.connected = False
            
    def _doConnectSvr(self):
        try:
            self.sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            self.sock.settimeout(5)
            self.sock.connect(self.endpoint)
            self.connected = True
        except Exception,ex:
            print "Connect server error, " , ex
            return False

        return True
        
    def _doSendAndRecv(self,sendcontent):
        sendsuccess=False
        try:
            self.sock.send(sendcontent)
            sendsuccess=True
            data = self.sock.recv(1024)
            if data:
                #print "recv[%s]" % codecs.encode(data,'hex')
                print "recv length[%d]" % len(data)
                return True,data
            else:
                print "recv data error!"
        except Exception,ex:
            if not sendsuccess:
                print "send data error, ",ex
            else:
                print "Recv data error, ", ex
        
        return False,''
        
    def _doAutoSendTest(self):
        from tcutils.performance import CheckPerf
        c = CheckPerf()
        c.startchk()
        for t in range(self.run_count):
            if not self.connected:
                if not self._doConnectSvr():
                    continue
            inputcontent = self.data_check.getcontent("login",t+1)
            r,outputcontent = self._doSendAndRecv(inputcontent)
            if r:
                if self.data_check.checkoutput("login",outputcontent,t+1):
                    print "Login success"
                    c.setchkpoint(True)
                else:
                    print "recv data not match!"
                    c.setchkpoint(False)
            else:
                print "Login Error"
                c.setchkpoint(False)
            self._closeSocket()
            
        print c.report(TestServer.ReportFile)
        self._closeSocket()
        
    def _doSendTest(self):
        while True:
            ans = raw_input('Send example data or Exit ?(Y/n/E(xit))')
            if ans in ('E','e','exit'):
                break
            if not (ans in ('Y','y','yes','','t','T')):
                continue
            if not self.connected:
                if not self._doConnectSvr():
                    continue
            if ans in ('t','T'):
                print "just connect to server ,but without sending data to server"
                continue
            
            inputcontent = self.data_check.getcontent("login",1)
            r,outputcontent = self._doSendAndRecv(inputcontent)
            if r:
                if not self.data_check.checkoutput("login",outputcontent,1):
                    return False
                raw_input('press any key to continue...')
                self._closeSocket()
                if not self._doConnectSvr():
                    print "connect error"
                    continue
                inputcontent = self.data_check.getcontent("batchupload",1);
                r,output = self._doSendAndRecv(inputcontent)
                if not r:
                    print "Batch upload error"
            else:
                print "Login Error"
           
            self._closeSocket()
            
        self._closeSocket()
        
    def run(self):
        self._doAutoSendTest()
        
    def manul_test(self):
        self._doSendTest()

class ClientMachine: 
    def __init__(self):
        self.svrip=""
        self.svrport=0
        self.sendpackfile="sendpack.txt"
        self.batchrecordfile="batchrecord.txt"
        self.logincontent=''
        self.batchuploadcontent=''
        self.sock = None
        self.connected = False
        self.autoTestTimes = 500
        self.autoTest=False
        self.autoTestThrdCount=1
        self.mackey=''

    def _doGenAutoRecord(self,content,traceno):
        traceno_data = struct.pack('>I',traceno)
        result = content[:17]
        result += traceno_data[1:]
        result += content[20:]
        return result
        
        
    def _doCheckAutoRecord(self,content,traceno):
        traceno_data = struct.pack('>I',traceno)
        test = content[17:20]
        return traceno_data[1:] == test
        
    def getcontent(self,typename,traceno):
        if "login" == typename:
            return self._doGenAutoRecord(self.logincontent,traceno)
        elif "batchupload" == typename:
            calc = CalcMac()
            calc.calc('testpack0001.txt',mackey=self.mackey)
            #return self.batchuploadcontent
            return calc.get_content()
        else:
            raise RuntimeError('Error data type')
            
    def checkoutput(self,typename,content,traceno):
        if "login" == typename:
            self.mackey = codecs.encode(content[153:169],'hex')
            print "mackey [%s]" % self.mackey
            #return self._doCheckAutoRecord(content,traceno)
            return True
        elif "batchupload" == typename:
            return self._doCheckAutoRecord(content,traceno)
        else:
            raise RuntimeError('Error data type')
        
    def _printUsage(self):
        print "Usage: "
        print "\t-h show this screen"
        print "\t-a auto test mode , default is manual test mode"
        print "\t-s server ip,default is 127.0.0.1"
        print "\t-p server port,default is 11000"
        print "\t-t thread count, auto test mode thread count"
        print "\t-c auto test mode test times per thread"
        
    def _doParseConfig(self,argv):
        self.svrip="127.0.0.1"
        self.svrport=11000
        args,optlist = getopt.getopt(argv,'has:p:c:t:')
        for n,v in args:
            if n == '-h':
                self._printUsage()
                return False
            elif n == '-a':
                self.autoTest = True
            elif n == '-s':
                self.svrip = v
            elif n == '-p':
                self.svrport = int(v)
            elif n == '-c':
                self.autoTestTimes = int(v)
            elif n == '-t':
                self.autoTestThrdCount = int(v)
            else:
                print "Error command [" , args ,"]"
                return False
        return True

    def _doAutoSendTestProxy(self):
        if not self.autoTest:
            t = TestServer((self.svrip,self.svrport),self,self.autoTestTimes)
            t.manul_test()
            return True
        
        # use multi-thread to run test
        threads=[]
        for i in range(self.autoTestThrdCount):
            t = TestServer((self.svrip,self.svrport),self,self.autoTestTimes)
            threads.append(t)
            t.start()
            
        for t in threads:
            t.join()
            
        print "Please check report file to verify result [%s]" % TestServer.ReportFile
        return True
        

    def execute(self,argv):
        if not self._doParseConfig(argv):
            return -1

        self.logincontent = ''
        for line in fileinput.input(self.sendpackfile):
            self.logincontent += codecs.decode(line,'hex')

        fileinput.close()
        
        self.batchuploadcontent=''
        for line in fileinput.input(self.batchrecordfile):
            self.batchuploadcontent += codecs.decode(line,'hex')

        fileinput.close()
        
        return self._doAutoSendTestProxy()


if __name__ == "__main__":
    client = ClientMachine()
    client.execute(sys.argv[1:])
