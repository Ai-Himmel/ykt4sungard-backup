#!/usr/bin/python
# -*- coding: gbk -*-
import sys,os,codecs
import fileinput,struct
import pyDes
from tcutils import pbocfunc


class CalcMac:
    def __init__(self):
        self.packfile='recvpack.txt'
        self.recvcontent=''
        self.mainkey = codecs.decode('6764796A676D6363','hex')
        
    def calc(self):
        if not self.loadData():
            return False
            
        if not self.parseData():
            return False
            
        return True
            
    def loadData(self):
        self.recvcontent=''
        for line in fileinput.input(self.packfile):
            self.recvcontent += codecs.decode(line.strip(),'hex')
            
        fileinput.close()
        return True
        
    def parseData(self):
        len_header = struct.unpack('>H',self.recvcontent[:2])
        print "data length :", len_header[0]
        if len(self.recvcontent) - 2 <> len_header[0]:
            print "data length error!"
            return False
        
        data = self.recvcontent[7:-8] # 
        data_mac = self.recvcontent[-8:] #
        
        mackey = codecs.decode("DBBF427E0CE43A942020202020202020",'hex')
        
        # MAC��Կ���㷽���� ����Կ 6764796A676D6363
        # 1. ʹ��des �� mac ��Կ����
        #key = pbocfunc.desencrypt(self.mainkey,mackey,pyDes.ECB)
        # 2. ʹ��des �� mac ��Կ����
        key = pbocfunc.desdecrypt(self.mainkey,mackey,pyDes.ECB)
        print codecs.encode(key,'hex')
        
        calc_mac = codecs.encode(self.calcMac2(data,key[:8]),'hex')
        data_mac = codecs.encode(data_mac,'hex')
        
        print "mac key check is ", self.calcMac(key,self.mainkey)
        
        if data_mac == calc_mac:
            print "Mac matched !"
            return True
            
        print "Mac mismatched! calc[%s],data[%s]" % (calc_mac,data_mac)
        return False
        
    def xorData(self,first,second):
        data_len = len(first)
        temp_data = ''
        #print codecs.encode(first,'hex')
        for j in range(data_len):
            a = ord(first[j]) & 0xFF
            b = ord(second[j]) & 0xFF
            t = a ^ b
            temp_data += chr(t)
        return temp_data
            
    def calcMac(self,data,key):
        padstr = codecs.decode("0000000000000000","hex")
        padlen = len(data) % 8
        if padlen > 0:
            data += padstr[:8-padlen]
        
        #print codecs.encode(data,'hex')
        
        init_data = data[:8]
        i = 8
        while i < len(data):
            init_data = self.xorData(init_data,data[i:i+8])
            i += 8
        
        # calc mac
        new_data = codecs.encode(init_data,'hex').upper()
        
        encrypt_data = pbocfunc.desencrypt(key,new_data[:8],pyDes.ECB)
        
        encrypt_data = self.xorData(encrypt_data,new_data[8:])
        
        encrypt_data = pbocfunc.desencrypt(key,encrypt_data,pyDes.ECB)
        
        new_data = codecs.encode(encrypt_data,'hex').upper()
        
        #print new_data
        
        return new_data[:8]
     
    def calcMac2(self,data,key):
        padstr = codecs.decode("0000000000000000","hex")
        padlen = len(data) % 8
        if padlen > 0:
            data += padstr[:8-padlen]
        
        print "len[%d]%s" % (len(data),codecs.encode(data,'hex'))
        
        init_data = pbocfunc.desencrypt(key,data[:8],pyDes.ECB)
        i = 8
        while i < len(data):
            temp_data = self.xorData(init_data,data[i:i+8])
            init_data = pbocfunc.desencrypt(key,temp_data,pyDes.ECB)
            i += 8
            
        print codecs.encode(init_data,'hex')
        return init_data
            
        
if __name__ == "__main__":
    mac = CalcMac()
    mac.calc()
    