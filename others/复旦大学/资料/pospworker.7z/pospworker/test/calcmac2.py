#!/usr/bin/python
# -*- coding: gbk -*-
import sys,os,codecs
import fileinput,struct,ConfigParser
import pyDes
from tcutils import pbocfunc


class CalcMac:
    def __init__(self):
        self.calc_file=''
        self.mainkey = '6764796A676D6363'
        self.mackey = ''
        # N for None B for begin , D for data , E for end
        self.state='N'
        self.content=''
        
    def calc(self,config_file,**keywords):
        self.calc_file = config_file
        if not self.loadData():
            return False
        if keywords.has_key('mackey'):
            self.mackey = keywords['mackey']
        elif keywords.has_key('mainkey'):
            self.mainkey = keywords['mainkey']
        elif keywords.has_key('content'):
            self.content = keywords['content']
        
        if not self.parseData():
            return False
            
        return True
        
    def get_content(self):
        header_str = struct.pack('>H',len(self.content) % 0xFFFF)
        header_str += self.content
        return header_str
        
    def get_value(self,line):
        ret = line.split('=')
        if len(ret)!=2:
            raise RuntimeError('line format error')
        return ret
        
    def parse_one_line(self,line):
        if line.startswith('#'):
            return True
        if line.startswith('mainkey'):
            self.mainkey = self.get_value(line)[1]
        elif line.startswith('mackey'):
            self.mackey = self.get_value(line)[1]
        elif line.startswith('data'):
            self.state = 'B'
        elif line.startswith('begin'):
            if self.state == 'B':
                self.state = 'D'
            else:
                raise ValueError("begin must follow [data] key")
        elif line.startswith('end'):
            if self.state == 'D':
                self.state='E'
            else:
                raise ValueError("begin must follow [begin] key")
        else:
            if self.state=='D':
                self.content += line
            else:
                return False
          
        return True
    def format_content(self,content):
        result = ''
        for i in content:
            if (i >= 'A' and i <= 'F' ) or ( i >= 'a' and i <= 'f') \
                or (i >= '0' and i <='9'):
                result += i
            elif i in (' ','\t'):
                continue
            else:
                raise ValueError("data error")
        return codecs.decode(result,'hex')
        
    def loadData(self):
        self.state='N'
        lineno=0
        for line in fileinput.input(self.calc_file):
            line=line.strip()
            lineno+=1
            if len(line) == 0: continue
            if not self.parse_one_line(line):
                print "config file line #%d error" % lineno
                return False
            
        fileinput.close()
        
        self.content = self.format_content(self.content)
        return True
        
    def parseData(self):
        len_header = len(self.content)
        print "data length :", len_header
        
        data = self.content[5:-8] # 
        data_mac = self.content[-8:] #
        
        mackey = codecs.decode(self.mackey,'hex')
        
        # MAC��Կ���㷽���� ����Կ 6764796A676D6363
        # 1. ʹ��des �� mac ��Կ����
        #key = pbocfunc.desencrypt(self.mainkey,mackey,pyDes.ECB)
        # 2. ʹ��des �� mac ��Կ����
        mainkey = codecs.decode(self.mainkey,'hex')
        key = pbocfunc.desdecrypt(mainkey,mackey,pyDes.ECB)
        print "mac key is : ",codecs.encode(key,'hex')
        
        calc_mac = codecs.encode(self.calcMac2(data,key[:8]),'hex')
        data_mac = codecs.encode(data_mac,'hex')
        
        #print "mac key check is ", self.calcMac(key,mainkey)
        
        if data_mac == calc_mac:
            print "Mac matched !"
            return True
            
        print "Mac mismatched! calc[%s],data[%s]" % (calc_mac,data_mac)
        self.content=self.content[:-8] + codecs.decode(calc_mac,'hex')
        return False
        
    def xorData(self,first,second):
        data_len = len(first)
        temp_data = ''
        #print codecs.encode(first,'hex')
        for j in range(data_len):
            a = ord(first[j]) & 0xFF
            b = ord(second[j]) & 0xFF
            t = a ^ b
            temp_data += chr(t)
        return temp_data
            
    
     
    def calcMac2(self,data,key):
        padstr = codecs.decode("0000000000000000","hex")
        padlen = len(data) % 8
        if padlen > 0:
            data += padstr[:8-padlen]
        
        print "len[%d]%s" % (len(data),codecs.encode(data,'hex'))
        
        init_data = pbocfunc.desencrypt(key,data[:8],pyDes.ECB)
        i = 8
        while i < len(data):
            temp_data = self.xorData(init_data,data[i:i+8])
            init_data = pbocfunc.desencrypt(key,temp_data,pyDes.ECB)
            i += 8
            
        print "MAC is :",codecs.encode(init_data,'hex')
        return init_data
            
        
if __name__ == "__main__":
    mac = CalcMac()
    mac.calc(sys.argv[1])
    