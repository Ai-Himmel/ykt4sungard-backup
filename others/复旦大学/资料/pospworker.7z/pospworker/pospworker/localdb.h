#ifndef _LOCALDB_H_
#define _LOCALDB_H_

#include <string>
#include "soci.h"

///////////////////////////////////////////////////////////////////////////////
class Ks8583Parser;

class TransactionGuard
{
public:
  TransactionGuard(soci::session& db,bool& commit);
  ~TransactionGuard();
private:
  soci::session& db_;
  bool &commit_flag_;
};
class LocalConfigDB
{
public:
  LocalConfigDB();
  ~LocalConfigDB();
  bool IsOpen();
  bool Open(const std::string &configdb);
  bool RegisterLogin(Ks8583Parser* response);
  bool GetPosMacKey(Ks8583Parser* response,char *mackey);
  std::string error_msg() const
  {
    return error_msg_;
  }
private:
  static const std::string kPosTable;
  soci::session db_;
  bool db_open_;
  std::string error_msg_;
};

#endif // _LOCALDB_H_
