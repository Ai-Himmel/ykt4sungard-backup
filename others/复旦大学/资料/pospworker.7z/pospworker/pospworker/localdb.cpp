#include <string>
#include <sstream>
#include "ks_8583_reader.h"
#include "localdb.h"
#include "sqlite3/soci-sqlite3.h"
///////////////////////////////////////////////////////////////////////////////
TransactionGuard::TransactionGuard(soci::session& db,bool& commit/* = true*/)
:db_(db),commit_flag_(commit)
{
  db_.begin();
}
TransactionGuard::~TransactionGuard()
{
  if(commit_flag_)
  {
    db_.commit();
  }
  else
  {
    db_.rollback();
  }
}
///////////////////////////////////////////////////////////////////////////////
const std::string LocalConfigDB::kPosTable = "pos";
LocalConfigDB::LocalConfigDB():db_open_(false)
{
}
LocalConfigDB::~LocalConfigDB()
{
  db_.close();
}
bool LocalConfigDB::IsOpen()
{
  return db_open_;
}
bool LocalConfigDB::Open(const std::string &configdb)
{
  std::string connstr = "dbname=" + configdb;
  connstr += " timeout=3";
  db_.open(soci::sqlite3,connstr);
  db_open_ = true;
  try
  {
    int count = 0;
    db_<<"select count(*) from "<<kPosTable<<" where 1<>1 ",soci::into(count);
    return true;
  }
  catch(std::exception &ex)
  {
    
  }
  // create table
  try
  {
    db_<<"create table "<<kPosTable<<" ( \n"
      <<"devphyid VARCHAR(16) not null,"
      <<"termsn VARCHAR(16) not null,"
      <<"termdate VARCHAR(8),"
      <<"termtime VARCHAR(6),"
      <<"termseqno integer,"
      <<"workkey VARCHAR(32),"
      <<"mackey VARCHAR(32),"
      <<"primary key (devphyid) )";
    ;
    return true;
  }
  catch(std::exception &ex)
  {
    error_msg_ = ex.what();
  }
  return false;
}
bool LocalConfigDB::RegisterLogin(Ks8583Parser* response)
{
  if(!db_open_)
    return false;
  bool commit = false;
  std::string devphyid;
  response->GetValueByName("pos_phyno",devphyid);
  if(devphyid.empty())
    return false;
  try
  {
    TransactionGuard guard(db_,commit);
    int count = 0;
    db_<<"SELECT count(*) FROM "<< kPosTable << " WHERE devphyid=:devphyid ",
      soci::into(count),soci::use(devphyid);
    
    // pos information
    std::string termsn,termdate,termtime,workkey,mackey,terminfo;
    int termseqno=0;
    response->GetValueByName("pos_no",termsn);
    response->GetValueByName("term_time",termtime);
    response->GetValueByName("term_date",termdate);
    response->GetValueByName("trace_pos",&termseqno);
    response->GetValueByName("cust_term_info",terminfo);
    size_t offset = 9 * 2;
    workkey = terminfo.substr(offset,32);
    offset += 32+8;
    mackey = terminfo.substr(offset,32);

    if(count == 0)
    {
      // add one
      db_<<"INSERT INTO "<<kPosTable
        <<"(devphyid,termsn,termdate,termtime,termseqno,workkey,mackey)"
        <<"values('"<<devphyid<<"','"<<termsn<<"','"<<termdate<<"','"<<termtime
        <<"',"<<termseqno<<",'"<<workkey<<"','"<<mackey<<"')";
      commit = true;
      return true;
      
    }
    else
    {
      // update one 
      db_<<"UPDATE "<<kPosTable
        <<" SET termsn='"<<termsn
        <<"',termdate='"<<termdate
        <<"',termtime='"<<termtime
        <<"',termseqno="<<termseqno
        <<",workkey='"<<workkey
        <<"',mackey='"<<mackey
        <<"' WHERE devphyid='"<<devphyid<<"'";
      commit = true;
      return true;
    }
  }
  catch(std::exception& ex)
  {
    error_msg_ = ex.what();
  }
  return false;
}
bool LocalConfigDB::GetPosMacKey(Ks8583Parser* response,char *mackey)
{
  if(!db_open_)
    return false;
  std::string devphyid;
  response->GetValueByName("pos_phyno",devphyid);
  if(devphyid.empty())
    return false;
  bool commit = true;
  try
  {
    TransactionGuard guard(db_,commit);
    std::string mackeystr;
    db_<<"SELECT mackey FROM "<<kPosTable<<" WHERE devphyid=:devphyid",
      soci::into(mackeystr),soci::use(devphyid);

    strcpy(mackey,mackeystr.c_str());
    return true;
  }
  catch(std::exception& ex)
  {
    error_msg_ = ex.what();
  }
  return false;
}