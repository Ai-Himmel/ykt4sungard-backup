#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include <string>
#include <map>
#include <vector>
#include "minIni.h"
#include "yktclt.h"

#define POSP_CONFIG_DB "pospconfig.db"

class WorkerConfig
{
 public:
  WorkerConfig();
  ~WorkerConfig();
  bool LoadConfig(const std::string& config);
  std::string& operator[](const std::string& para_name);
  bool HasValue(const std::string& para_name);
 private:
  typedef std::map<std::string,std::string> ParamValueType;
  WorkerConfig(const WorkerConfig&);
  WorkerConfig& operator=(const WorkerConfig&);
  void LoadSectionValues(minIni& ini,const std::string& section_name);
  void SaveParamValues(const std::string& section_name,ParamValueType::value_type& item);
  ParamValueType values_;
};


// ��ȡȫ�ֶ���
KS_YKT_Clt& GetBCCClt();
#define CLT_GET_STR(clt,f,v) do { clt.GetStringFieldByName(f,v,sizeof(v)-1); }while(0)

#endif // _GLOBAL_H_
