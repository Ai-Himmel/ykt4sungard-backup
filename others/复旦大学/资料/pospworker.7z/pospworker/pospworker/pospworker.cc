#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <map>
#include <boost/shared_ptr.hpp>
#include <boost/bind.hpp>
#include "fdxslib.h"
#include "fdxslib_sharedmemory.h"
#include "fdxslib_socket.h"
#include "XGetopt.h"
#include "ks_8583_reader.h"
#include "unit_def.h"
#include "minIni.h"
#include "yktclt.h"
#include "global.h"
#include "global_func.h"
#include "des.h"
#include "localdb.h"
#ifdef WIN32
#include <windows.h>
#endif

using namespace std;

static std::ofstream g_logger( "workerlog.txt", ios_base::app | ios_base::binary );

#define WORKER_VERSION "v1.0 "__DATE__
///////////////////////////////////////////////////////////////////////////////
static int posp_calc_mac( Ks8583Parser::CalcMacParam* param );
static unsigned char g_main_key[32] = {0};
static int g_main_key_length = 0;
///////////////////////////////////////////////////////////////////////////////
KS_YKT_Clt* global_clt = NULL;
KS_YKT_Clt& GetBCCClt()
{
  if( NULL == global_clt )
  {
    global_clt = new KS_YKT_Clt();
  }
  return *global_clt;
}
///////////////////////////////////////////////////////////////////////////////
WorkerConfig::WorkerConfig()
{
}
WorkerConfig::~WorkerConfig()
{
  values_.clear();
}
bool WorkerConfig::LoadConfig( const std::string& config )
{
  minIni ini( config );
  std::vector<std::string> sections;
  for( std::size_t sect_index = 0;; ++sect_index )
  {
    std::string sect_name = ini.getsection( sect_index );
    if( sect_name.empty() )
      break;
    sections.push_back( sect_name );
  }
  std::for_each( sections.begin(), sections.end(),
                 boost::bind( &WorkerConfig::LoadSectionValues, this, ini, _1 ) );

  return true;
}
void WorkerConfig::LoadSectionValues( minIni& ini, const std::string& section_name )
{
  ParamValueType val;
  for( std::size_t key_index = 0;; ++key_index )
  {
    std::string key_name = ini.getkey( section_name, key_index );
    if( key_name.empty() )
      break;
    std::string key_value = ini.gets( section_name, key_name );
    val[key_name] = key_value;
  }
  std::for_each( val.begin(), val.end(),
                 boost::bind( &WorkerConfig::SaveParamValues, this, section_name, _1 ) );
}
void WorkerConfig::SaveParamValues( const std::string& section_name,
                                    ParamValueType::value_type& item )
{
  std::string p = section_name;
  p += ".";
  p += item.first;
  values_[p] = item.second;
}
std::string& WorkerConfig::operator[]( const std::string& para_name )
{
  return values_[para_name];
}
bool WorkerConfig::HasValue( const std::string& para_name )
{
  return ( values_.find( para_name ) != values_.end() );
}
///////////////////////////////////////////////////////////////////////////////
class Worker
{
public:
  Worker();
  ~Worker();
  int Run( int argc, char* const argv[] );
private:
  typedef boost::shared_ptr<Ks8583Parser> ParserPtr;
  int DoRealWork();
  void StopClient();
  bool StartClient();
  int ProcessRequest();
  void PrintUsage();
  bool LoadPkgDefine();
  bool LoadConfigFile();
  bool ServerConnect();
  bool DownloadParams();
  void PrintVersion();
  std::string config_file_;
  std::string session_name_;
  std::size_t work_timeout_;
  FDXSLib::FDXSWorkerClient* client_;
  char message_buffer_[8192];
  std::size_t message_length_;
  char pkg_defing_name_[256];
  static const char pkg_define_file_[];
  WorkerConfig config_;
};
const char Worker::pkg_define_file_[] = "posp8583.dat";

Worker::Worker(): client_( NULL ), work_timeout_( 3000 ), message_length_( 0 )
{
}
Worker::~Worker()
{
  Ks8583Parser::FreeAllDefines();
  PospWorkerManager::Free();
  StopClient();
}
int Worker::Run( int argc, char* const argv[] )
{
  const char short_opts[] = "hvc:s:";
  int option;
  while( ( option = getopt( argc, argv, short_opts ) ) != EOF )
  {
    switch( option )
    {
    case 'c':
      config_file_ = optarg;
      break;
    case 'h':
      PrintUsage();
      return 0;
    case 'v':
      PrintVersion();
      return 0;
    case 's':
      session_name_ = optarg;
      break;
    default:
      return -1;
    }
  }
  if( session_name_.empty() )
  {
    cout << "must specify session key name" << endl;
    return -1;
  }
  if( config_file_.empty() )
  {
    config_file_ = "./workercfg.ini";
  }
#if 0
  char full_path[2048] = {0};
  ::GetCurrentDirectory( sizeof( full_path ) - 1, full_path );
  std::string fn = "c:\\posp_";
  fn += session_name_;
  fn += ".txt";
  std::fstream fs( fn.c_str(), std::ios_base::app | std::ios_base::binary );
  fs << full_path;
  fs.close();
#endif
  return DoRealWork();
}
void Worker::PrintUsage()
{
}
void Worker::PrintVersion()
{
  std::cout << "Version : " << WORKER_VERSION;
#ifdef DEBUG
  std::cout << " DEBUG" << std::endl;
#else
  std::cout << " RELEASE" << std::endl;
#endif;
}
bool Worker::LoadConfigFile()
{
  return config_.LoadConfig( config_file_ );
}
bool Worker::LoadPkgDefine()
{
  std::string define_file = "./";
  define_file += pkg_define_file_;
  int ret = Ks8583Parser::Load8583Define( define_file.c_str(), pkg_defing_name_ );
  if( ret )
    return false;

  return true;
}
bool Worker::ServerConnect()
{
  std::string ip = config_["server.ip"];
  int port = atoi( config_["server.port"].c_str() );
  int mainfunc = atoi( config_["server.mainfunc"].c_str() );
  std::string xpack = config_["server.xpack"];
  if( ip.empty() || port == 0 || mainfunc == 0 )
    return false;

  bool ret = KS_YKT_Clt::Initialize( ip.c_str(), port, mainfunc );
  if( !ret )
  {
    return false;
  }
  if( xpack.empty() )
    xpack = "./cpack.dat";

  KS_YKT_Clt::set_xpack_path( xpack.c_str() );
#ifdef _DEBUG
  KS_YKT_Clt::SetDebug( 1 );
#else
  KS_YKT_Clt::SetDebug( 0 );
#endif
  return DownloadParams();
}
bool Worker::DownloadParams()
{
  KS_YKT_Clt& clt = GetBCCClt();
  clt.SetIntFieldByName( "lvol0", 111 ); // POSP Main key
  if( !clt.SendRequest( 820405 ) )
  {
    return false;
  }
  if( clt.GetReturnCode() != 0 )
    return false;

  if( clt.GetNextPackage() )
  {
    char maxvalue[256];
    memset( maxvalue, 0, sizeof maxvalue );
    clt.GetStringFieldByName( "scard0", maxvalue, sizeof( maxvalue ) - 1 );

    hex2dec( maxvalue, strlen( maxvalue ), g_main_key, g_main_key_length );
    return true;
  }
  return false;
}
int Worker::DoRealWork()
{
  if( !LoadPkgDefine() )
  {
    cout << "cannot load define file [" << pkg_define_file_ << "]" << endl;
    return -1;
  }
  if( !LoadConfigFile() )
  {
    cout << "cannot laod config file [" << config_file_ << "]" << endl;
    return -1;
  }
  if( !ServerConnect() )
  {
    cout << "cannot connect to server" << endl;
    return -1;
  }
  if( !StartClient() )
  {
    cout << "connect to server error!" << endl;
    return -1;
  }
  while( !client_->IsDisconnected() )
  {
    FDXSLib::FDXSMessage request( message_buffer_, 0 );
    request.set_max_length( sizeof( message_buffer_ ) );
    //std::cout<<"��ʼ��������"<<std::endl;
    if( client_->RecvData( request, 20000 ) )
    {
      // �������ݴ���
      continue;
    }
    message_length_ = request.length();
    //std::cout<<"Recv Message :"<<request.message_id()<<std::endl;
    // g_logger<<"Recv Message :"<<request.message_id()<<std::endl;
    // process request
    if( ProcessRequest() )
    {
      // ���ݴ���
      continue;
    }
    FDXSLib::FDXSMessage response( message_buffer_, message_length_ );
    response.new_message_id( request.message_id() );
    //std::cout<<"Send Message :"<<response.message_id()<<std::endl;
    //g_logger<<"Send Message :"<<response.message_id()<<std::endl;
    if( client_->SendData( response, 2000 ) )
    {
      // �������ݴ���
      continue;
    }
    //cout<<"process request success"<<endl;
  }
  std::cout << "���������˳�" << endl;
  StopClient();
  return 0;
}
int Worker::ProcessRequest()
{
  // ���Ը���ҵ���޸ĸô��Ĵ���
  ParserPtr request( Ks8583Parser::GetInstance( pkg_defing_name_ ) );
  int ret;
  std::size_t header_len = 5;
  request->SetCalcMacCallback( posp_calc_mac );
  ret = request->UnpackData( message_buffer_ + header_len, message_length_ - header_len );
  if( ret )
  {
    // TODO : ��Ϣԭ������
    cout << "recv message invalidate" << endl;
    return 0;
  }
  ParserPtr response( Ks8583Parser::GetInstance( pkg_defing_name_ ) );
  BufferType result;
  result.assign( 0 );
  size_t msg_length = 0;
  int error_code = 99;

  std::string msg_type;
  request->GetValueByName( "msg_type", msg_type );
  cout << "msgtype:" << msg_type << endl;

  PospWorkerUnit* unit = PospWorkerManager::GetInstance()->FindUnit( msg_type );
  if( unit == NULL )
  {
    cout << "cannot found unit for msg :" << msg_type << endl;
    // ��Ч����
    PospWorkerUnit::CommonError( request.get(), response.get(), 3 );
  }
  else
  {
    ret = unit->ProcessRequest( request.get(), response.get(), error_code );


    response->SetCalcMacCallback( posp_calc_mac );
    if( ret == PospWorkerUnit::succ_needmac || ret == PospWorkerUnit::success )
    {
      response->PackData( result, &msg_length, ret == PospWorkerUnit::succ_needmac );
    }
    else
    {
      // ����ʱ��ͨ�÷���
      switch( ret )
      {
      case PospWorkerUnit::execute_error:
        PospWorkerUnit::CommonError( request.get(), response.get(), error_code );
        break;
      case PospWorkerUnit::server_timeout:
      default:
        PospWorkerUnit::CommonError( request.get(), response.get(), 99 );
        break;
      }
    }
  }
  char temp[2];
  memcpy( temp, message_buffer_ + 1, 2 );
  memcpy( message_buffer_ + 1, message_buffer_ + 3, 2 );
  memcpy( message_buffer_ + 3, temp, 2 );
  memcpy( message_buffer_ + header_len, result.data(), msg_length );
  message_length_ = msg_length + header_len;
  cout << "reponse length " << message_length_ << endl;
  return 0;
}
void Worker::StopClient()
{
  if( client_ != NULL )
  {
    client_->DisconnectServer();
    delete client_;
    client_ = NULL;
  }
  cout << "Close client" << endl;
}
bool Worker::StartClient()
{
  int serverport = atoi( this->session_name_.c_str() );
  std::string connect_string;
  if( serverport > 0 )
  {
    if( !FDXSLib::FDXSLib_LoadImpl( FDXSLib::socket ) )
      throw std::runtime_error( "cannot load socket communication" );
    connect_string = "port=";
    connect_string += this->session_name_;
  }
  else
  {
    if( !FDXSLib::FDXSLib_LoadImpl( FDXSLib::sharedmemory ) )
      throw std::runtime_error( "cannot load shared memory communication" );
    connect_string = this->session_name_;
  }
  if( client_ != NULL )
    StopClient();
  client_ = new FDXSLib::FDXSWorkerClient( connect_string );
  if( client_->ConnectServer() )
    return true;
  cout << client_->last_error() << endl;
  return false;
}
///////////////////////////////////////////////////////////////////////////////
static int posp_calc_mac( Ks8583Parser::CalcMacParam* param )
{
  /// get mac key first
  char mac_key_str[33];
  memset( mac_key_str, 0, sizeof mac_key_str );
  {
    LocalConfigDB db;
    if( !db.Open( POSP_CONFIG_DB ) )
    {
      cout << "Cannot open config file" << endl;
      return -1;
    }

    if( !db.GetPosMacKey( param->parser, mac_key_str ) )
    {
      cout << "Cannot get mac key ," << db.error_msg() << endl;
      return -1;
    }
  }

  // decrypt mac key
  des_context ctx;
  unsigned char mac_key[8];
  int mac_key_len = 0;
  hex2dec( mac_key_str, 16, mac_key, mac_key_len );
  memset( &ctx, 0, sizeof ctx );
  des_set_key( &ctx, g_main_key );
  des_decrypt( &ctx, mac_key, mac_key );

  // calc mac
  size_t pad = 0;
  unsigned char init_data[8];
  memset( init_data, 0, sizeof init_data );
  for( pad = 0; pad < param->data_len; pad += 8 )
  {
    for( size_t i = 0; i < 8; i++ )
    {
      if( param->data_len > pad + i )
        init_data[i] ^= param->data[pad + i];
    }
    memset( &ctx, 0, sizeof ctx );
    des_set_key( &ctx, mac_key );
    des_encrypt( &ctx, init_data, init_data );
  }
  memcpy( param->mac, init_data, 8 );
  param->mac_len = 8;
  return 0;
}
///////////////////////////////////////////////////////////////////////////////
int main( int argc, char* const argv[] )
{

  Worker worker;
  return worker.Run( argc, argv );
}
