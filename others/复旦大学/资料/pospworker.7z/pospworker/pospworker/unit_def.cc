#include <boost/bind.hpp>

#include "unit_def.h"
#include "ks_8583_reader.h"
#include "global.h"
#include "global_func.h"
#include "des.h"
#include "localdb.h"

#define REGISTER_UNIT(code,unit) bool _u##unit = PospWorkerManager::GetInstance()->RegisterUnit(#code,new unit);

///////////////////////////////////////////////////////////////////////////////
PospWorkerManager* PospWorkerManager::instance_ = NULL;
PospWorkerManager* PospWorkerManager::GetInstance()
{
  if(NULL == instance_)
  {
    instance_ = new PospWorkerManager();
  }
  return instance_;
}
void PospWorkerManager::Free()
{
  if(NULL != instance_)
  {
    delete instance_;
    instance_ = NULL;
  }
}
PospWorkerManager::~PospWorkerManager()
{
  std::for_each(worker_unit_map_.begin(),worker_unit_map_.end(),
                boost::bind(&PospWorkerManager::FreeUnit,this,_1));
  worker_unit_map_.clear();
}
bool PospWorkerManager::RegisterUnit(const std::string &code,PospWorkerUnit * unit)
{
  if(FindUnit(code)!=NULL)
    return false;
  worker_unit_map_[code] = unit;
  return true;
}
void PospWorkerManager::FreeUnit(WorkerUnitMap::value_type& item)
{
  PospWorkerUnit* unit = item.second;
  delete unit;
}
PospWorkerUnit* PospWorkerManager::FindUnit(const std::string& code)
{
  WorkerUnitMap::iterator iter = worker_unit_map_.find(code);
  if(iter == worker_unit_map_.end())
    return NULL;
  return iter->second;
}
///////////////////////////////////////////////////////////////////////////////
void PospWorkerUnit::CopyFieldValue(Ks8583Parser* from,Ks8583Parser* to,
                                    const std::string& field_name)
{
  std::string temp;
  if(!from->GetValueByName(field_name,temp))
    to->SetValueByName(field_name,temp);
}
void PospWorkerUnit::SetBCCStringValue(KS_YKT_Clt& clt,
                                       Ks8583Parser *request,
                                       const std::string& bcc_field,
                                       const std::string& field_name)
{
  std::string value;
  request->GetValueByName(field_name,value);
  clt.SetStringFieldByName(bcc_field.c_str(),value.c_str());
}
void PospWorkerUnit::SetBCCIntValue(KS_YKT_Clt& clt,
                                    Ks8583Parser *request,
                                    const std::string& bcc_field,
                                    const std::string& field_name)
{
  std::string value;
  request->GetValueByName(field_name,value);
  clt.SetIntFieldByName((char*)field_name.c_str(),atoi(value.c_str()));
  
}
void PospWorkerUnit::CommonError(Ks8583Parser* request,Ks8583Parser* response,int response_code)
{
  CopyFieldValue(request,response,"msg_type");
  CopyFieldValue(request,response,"trace_pos");
  CopyFieldValue(request,response,"term_time");
  CopyFieldValue(request,response,"term_date");
  CopyFieldValue(request,response,"pos_phyno");
  CopyFieldValue(request,response,"pos_no");
  response->SetValueByName("response_code",response_code);
}

///////////////////////////////////////////////////////////////////////////////
class PosLoginUnit : public PospWorkerUnit
{
 public:
  virtual int ProcessRequest(Ks8583Parser* request,Ks8583Parser* response,int &error_code);
};
REGISTER_UNIT(0800,PosLoginUnit)

int PosLoginUnit::ProcessRequest(Ks8583Parser* request,Ks8583Parser* response,int &error_code)
{
  response->SetValueByName("msg_type","0810");
  KS_YKT_Clt &clt = GetBCCClt();
  clt.ResetHandler();
  SetBCCStringValue(clt,request,"sphone","pos_phyno");
  SetBCCStringValue(clt,request,"sname","pos_no");
  SetBCCStringValue(clt,request,"sdate0","term_date");
  SetBCCStringValue(clt,request,"stime0","term_time");
  SetBCCStringValue(clt,request,"scust_auth","merchant_no");

  
  if(!clt.SendRequest(2050,3000))
    return server_timeout;
  if(clt.GetReturnCode() != 0)
  {
    error_code = clt.GetReturnCode();
    return execute_error;
  }
  else
  {
    unsigned char cust_term_info[64];
    memset(cust_term_info,0,sizeof cust_term_info);
    int offset = 0;
    if(clt.HasMoreRecord())
    {
      clt.GetNextPackage();
      char hostdate[9] = {0};
      char hosttime[7] = {0};

      CLT_GET_STR(clt,"sdate0",hostdate);
      CLT_GET_STR(clt,"stime0",hosttime);

      // strcpy(hostdate,"20110408");
      // strcpy(hosttime,"091537");
      offset = 2;
      int len;
      asc2bcd(hostdate,8,cust_term_info+offset,len);
      offset+=4;
      asc2bcd(hosttime,6,cust_term_info+offset,len);
      offset+=3;

      char work_key[33] = {0};
      CLT_GET_STR(clt,"scust_auth",work_key);
      hex2dec(work_key,16,cust_term_info+offset,len);
      memset(cust_term_info+offset+8,0x20,8);
      offset+=16;
      memcpy(cust_term_info+offset,"\x46\x38\x36\x36",4);
      offset+=4;

      char mac_key[33] = {0};
      CLT_GET_STR(clt,"scust_auth2",mac_key);
      hex2dec(mac_key,16,cust_term_info+offset,len);
      memset(cust_term_info+offset+8,0x20,8);
      offset+=16;
      memcpy(cust_term_info+offset,"\x46\x38\x36\x36",4);
      offset+=4;

    }
    response->SetBufferByName("cust_term_info",(const char*)cust_term_info,offset);
    response->SetValueByName("response_code","00");
    CopyFieldValue(request,response,"trace_pos");
    CopyFieldValue(request,response,"term_time");
    CopyFieldValue(request,response,"term_date");
    CopyFieldValue(request,response,"pos_phyno");
    CopyFieldValue(request,response,"pos_no");
    CopyFieldValue(request,response,"merchant_no");
    CopyFieldValue(request,response,"cust_app_info");
    // �����뿽��
    LocalConfigDB db;
    if(db.Open(POSP_CONFIG_DB))
    {
      db.RegisterLogin(response);
    }
  }
  return PospWorkerUnit::succ_needmac;
}

///////////////////////////////////////////////////////////////////////////////
class PosBatchUploadUnit : public PospWorkerUnit
{
 public:
  virtual int ProcessRequest(Ks8583Parser* request,Ks8583Parser* response,int &error_code);
 protected:
  struct RecordDefine
  {
    char aid[17];
    int trans_type;
    char cardasno[20];
    int amount;
    char trans_date[9];
    char trans_time[7];
    int posseqno;
    int issue_code;
    int key_index;
    int key_version;
    int pay_count;
    char tac[9];
    char samno[20];
    char samseqno;
    int cardaftbalance;
  };
  bool DecodeRecord(RecordDefine &record,unsigned char *data);
  int SaveRecord(KS_YKT_Clt& clt,Ks8583Parser* request,RecordDefine &record);
  static const size_t kRecordLength = 85;
};
REGISTER_UNIT(0300,PosBatchUploadUnit) 

int PosBatchUploadUnit::ProcessRequest(Ks8583Parser* request,Ks8583Parser* response,int &error_code)
{
  response->SetValueByName("msg_type","0310");
  CopyFieldValue(request,response,"trans_type");
  CopyFieldValue(request,response,"trace_pos");
  CopyFieldValue(request,response,"term_time");
  CopyFieldValue(request,response,"term_date");
  CopyFieldValue(request,response,"settle_date");
  CopyFieldValue(request,response,"pos_phyno");
  CopyFieldValue(request,response,"pos_no");
  CopyFieldValue(request,response,"merchant_no");
  CopyFieldValue(request,response,"currency_code");
  
  std::string record_string;
  request->GetValueByName("cust_batch_data",record_string);
  unsigned char batch_data[8192] = {0};
  int batch_len = 0;
  hex2dec(record_string.c_str(),record_string.length(),batch_data,batch_len);
  KS_YKT_Clt &clt = GetBCCClt();
  
  if(batch_len == 0)
  {
    response->SetValueByName("response_code","03");
  }
  else
  {
    int offset = 0;
    int flag = batch_data[offset++];
    int record_count = batch_data[offset++];
    if(record_count > 5)
    {
      response->SetValueByName("response_code","03");
    }
    else
    {
      int i = 0;
      char hostdate[9]={0};
      for(i = 0;i < record_count; ++i)
      {
        RecordDefine record;
        memset(&record,0,sizeof record);
        bool r = DecodeRecord(record,batch_data+offset);
        if(!r)
        {
          response->SetValueByName("response_code","03");
          break;
        }
        clt.ResetHandler();
        int ret_code  = SaveRecord(clt,request,record);
        if(ret_code)
        {
          response->SetValueByName("response_code",ret_code);
          break;
        }
        if(clt.HasMoreRecord())
        {
          clt.GetNextPackage();
          CLT_GET_STR(clt,"sdate0",hostdate);
        }
        offset += kRecordLength;
      }
      if( i == record_count )
      {
        response->SetValueByName("settle_date",std::string(hostdate+4));
        response->SetValueByName("response_code","00");
      }
    }
  }
  return succ_needmac;
}
bool PosBatchUploadUnit::DecodeRecord(RecordDefine &record,unsigned char *data)
{
  char temp[64];
  int offset = 0;
  memcpy(record.aid,data,16);
  offset+=16;

  record.trans_type = data[offset++];

  bcd2asc(data+offset,10,record.cardasno);
  offset+=10;

  offset+=6;
  

  bcd2asc(data+offset,4,record.trans_date);
  offset+=4;

  bcd2asc(data+offset,3,record.trans_time);
  offset+=3;

  memset(temp,0,sizeof temp);
  bcd2asc(data+offset,3,temp);
  offset+=3;
  record.posseqno = atoi(temp);

  memset(temp,0,sizeof temp);
  memcpy(temp,data+offset,8);
  offset+=8;
  record.issue_code = atoi(temp);

  record.key_index = data[offset++];

  record.key_version = data[offset++];

  record.pay_count = get_2byte_int(data+offset);
  offset+=2;

  dec2hex(data+offset,4,record.tac);
  offset+=4;

  record.amount = get_4byte_int(data+offset);
  offset+=4;

  offset++;

  bcd2asc(data+offset,6,record.samno);
  offset+=6;

  record.samseqno = get_4byte_int(data+offset);
  offset+=4;

  offset += 4 + 3;

  record.cardaftbalance = get_4byte_int(data+offset);
  offset+=4;

  return (offset == kRecordLength);
}
int PosBatchUploadUnit::SaveRecord(KS_YKT_Clt& clt,Ks8583Parser* request,RecordDefine &record)
{
  std::string pos_phyno,pos_no,merchant_no;
  request->GetValueByName("pos_phyno",pos_phyno);
  request->GetValueByName("pos_no",pos_no);
  request->GetValueByName("merchant_no",merchant_no);
  /////////////////////////////////////////////////////
  clt.SetStringFieldByName("sphone",pos_phyno.c_str());
  clt.SetStringFieldByName("sname",pos_no.c_str());
  clt.SetStringFieldByName("sdate0",record.trans_date);
  clt.SetStringFieldByName("stime0",record.trans_time);
  clt.SetIntFieldByName("lserial0",record.posseqno);
  clt.SetStringFieldByName("scust_auth2",merchant_no.c_str());
  clt.SetIntFieldByName("lvol0",record.key_index);
  clt.SetIntFieldByName("lvol1",record.key_version);
  clt.SetStringFieldByName("scust_limit",record.samno);
  clt.SetIntFieldByName("lvol2",record.samseqno);
  clt.SetStringFieldByName("sname2",record.tac);
  clt.SetIntFieldByName("lvol6",record.pay_count);
  clt.SetIntFieldByName("lvol7",record.cardaftbalance + record.amount);
  clt.SetIntFieldByName("lvol8",record.amount);
  clt.SetIntFieldByName("lvol9",record.cardaftbalance);
  clt.SetStringFieldByName("scust_auth",record.cardasno);
  clt.SetIntFieldByName("lvol3",record.trans_type);

  if(!clt.SendRequest(2051,3000))
  {
    return 99;
  }
  if(clt.GetReturnCode() != 0)
    return clt.GetReturnCode();
  return 0;
}
