#ifndef _UNIT_DEF_H_
#define _UNIT_DEF_H_
#include <string>
#include <map>
#include "yktclt.h"

class Ks8583Parser;
class PospWorkerUnit
{
 public:
  enum { success = 0,server_timeout,execute_error,succ_needmac };
  PospWorkerUnit()
  {
  }
  virtual ~PospWorkerUnit()
  {
  }
  static void CopyFieldValue(Ks8583Parser* from,Ks8583Parser* to,const std::string& field_name);
  static void SetBCCStringValue(KS_YKT_Clt& clt,Ks8583Parser *request,
                         const std::string& bcc_field,const std::string& field_name);
  static void SetBCCIntValue(KS_YKT_Clt& clt,Ks8583Parser *request,
                      const std::string& bcc_field,const std::string& field_name);
  virtual int ProcessRequest(Ks8583Parser* request,Ks8583Parser* response,int &error_code) = 0;

  static void CommonError(Ks8583Parser* request,Ks8583Parser* response,int response_code);
};

class PospWorkerManager
{
 public:
  ~PospWorkerManager();
  bool RegisterUnit(const std::string &code,PospWorkerUnit * unit);
  PospWorkerUnit* FindUnit(const std::string& code);
  static PospWorkerManager* GetInstance();
  static void Free();
 private:
  typedef std::map<std::string,PospWorkerUnit*> WorkerUnitMap;
  PospWorkerManager()
  {
  }
  void FreeUnit(WorkerUnitMap::value_type& item);
  static PospWorkerManager * instance_;
  WorkerUnitMap worker_unit_map_;
};


#endif // _UNIT_DEF_H_

