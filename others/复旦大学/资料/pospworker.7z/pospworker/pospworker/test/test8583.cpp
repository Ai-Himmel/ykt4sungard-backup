#define BOOST_TEST_MODULE test8583
#include <map>
#include <string>
#include <boost/shared_ptr.hpp>
#include <boost/test/unit_test.hpp>
#include "../ks_8583_reader.h"
#include "../global_func.h"

typedef boost::shared_ptr<Ks8583Parser> ParserPtr;

void CopyFieldValue(ParserPtr& from,ParserPtr& to,const std::string& field_name)
{
  std::string value;
  from->GetValueByName(field_name,value);
  to->SetValueByName(field_name,value);
}

static std::string pack_define_file="posp8583.dat";

struct DefineGuard
{
  DefineGuard():load_result(-1)
  {
    char define_name[256]={0};
    load_result = Ks8583Parser::Load8583Define(pack_define_file.c_str(),define_name);
  }
  ~DefineGuard()
  {
    Ks8583Parser::FreeAllDefines();
  }
  bool operator!()
  {
    return (!load_result);
  }
private:
  int load_result;
};

BOOST_AUTO_TEST_SUITE(test8583)

BOOST_AUTO_TEST_CASE( testLoadPack )
{
  // ���Լ��� ��ݸ�ƶ� POSP 8583 Э�������ļ�
  char define_name[256]={0};
  int ret = Ks8583Parser::Load8583Define(pack_define_file.c_str(),define_name);
  BOOST_CHECK(ret == 0);
  BOOST_CHECK(strcmp(define_name,"dgposp")==0);
  ParserPtr parser = ParserPtr(Ks8583Parser::GetInstance("dgposp"));
  BOOST_CHECK(parser != 0);

  Ks8583Parser::FreeAllDefines();
  parser = ParserPtr(Ks8583Parser::GetInstance("dgposp"));
  BOOST_CHECK(parser == 0);


}
BOOST_AUTO_TEST_CASE( testPack1 )
{
  DefineGuard guard;
  ParserPtr parser = ParserPtr(Ks8583Parser::GetInstance("dgposp"));
  BOOST_CHECK(parser != 0);
  // test set error field value
  BOOST_CHECK(parser->SetValueByName("msg_type","201010") != 0);
  BOOST_CHECK(parser->SetValueByIndex(2,"192002331920023319200233") != 0);
  BOOST_CHECK(parser->SetValueByName("term_date","201103") != 0);
  
  BOOST_CHECK(parser->SetValueByName("msg_type","2010") == 0);
  BOOST_CHECK(parser->SetValueByIndex(2,"19200233") == 0);
  BOOST_CHECK(parser->SetValueByName("trans_type","002901") == 0);
  BOOST_CHECK(parser->SetValueByName("trans_amount",123) == 0);
    
  BufferType msg;
  msg.assign(0);
  size_t msg_length = 0;
  int ret = parser->PackData(msg,&msg_length);
  BOOST_CHECK(ret == 0);

  ParserPtr reader = ParserPtr(Ks8583Parser::GetInstance("dgposp"));
  BOOST_CHECK(reader != 0);
  ret = reader->UnpackData(msg.data(),msg_length);
  BOOST_CHECK(ret == 0);

  std::string value;
  reader->GetValueByName("msg_type",value);
  BOOST_CHECK(value == "2010");
  reader->GetValueByName("account",value);
  BOOST_CHECK(value == "19200233");
  reader->GetValueByIndex(3,value);
  BOOST_CHECK(value == "002901");
  int iValue;
  reader->GetValueByIndex(4,&iValue);
  BOOST_CHECK(iValue == 123);
    
}
BOOST_AUTO_TEST_CASE( testPack2 )
{
  DefineGuard guard;
  ParserPtr parser = ParserPtr(Ks8583Parser::GetInstance("dgposp"));
  BOOST_CHECK(parser);

  BOOST_CHECK(parser->SetValueByIndex(2,"19200233") == 0);
  BufferType msg;
  msg.assign(0);
  size_t msg_length = 0;
  int ret = parser->PackData(msg,&msg_length);
  BOOST_CHECK(ret != 0);
}

BOOST_AUTO_TEST_CASE( testLoginPack )
{
  DefineGuard guard;
  ParserPtr parser = ParserPtr(Ks8583Parser::GetInstance("dgposp"));
  BOOST_CHECK(parser);

  char data_hex[]="08000038000001C00010000001090931201104084444444444444444444431323334353630303031393930323130333131343030313030303139390072A00000000386980701202020202020203030303030303030303030303030303030303030303030303030303030304646303130303030303130312020202020203030303030303030";
  unsigned char data[256] = {0};
  int data_len;

  hex2dec(data_hex,strlen(data_hex),data,data_len);

  int ret = parser->UnpackData((const char*)data,data_len);
  BOOST_CHECK(ret == 0);

  ParserPtr resp = ParserPtr(Ks8583Parser::GetInstance("dgposp"));
  
  CopyFieldValue(parser,resp,"msg_type");
  CopyFieldValue(parser,resp,"trace_pos");
  CopyFieldValue(parser,resp,"term_time");
  CopyFieldValue(parser,resp,"term_date");
  CopyFieldValue(parser,resp,"pos_phyno");
  CopyFieldValue(parser,resp,"pos_no");
  CopyFieldValue(parser,resp,"merchant_no");
  CopyFieldValue(parser,resp,"cust_app_info");

  BufferType toMsg;
  toMsg.assign(0);
  std::size_t msg_length;
  resp->PackData(toMsg,&msg_length);

  BOOST_CHECK(data_len == msg_length);
  BOOST_CHECK(memcmp(data,toMsg.data(),data_len)==0);

}
BOOST_AUTO_TEST_SUITE_END()
