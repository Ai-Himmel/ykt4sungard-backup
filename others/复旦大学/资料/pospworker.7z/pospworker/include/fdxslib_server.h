#ifndef _FDXSLIB_SERVER_H_
#define _FDXSLIB_SERVER_H_

#include <string>

namespace FDXSLib {
class FDXSCommunication
{
 public:
  explicit FDXSCommunication(const std::string tunnle_name,std::size_t buf_max_size)
    :tunnle_name_(tunnle_name),buffer_max_size_(buf_max_size)
  {
  }
  virtual ~FDXSCommunication()
  {
  }
  virtual int SendMessage(FDXSMessage &message,int timeout) = 0;
  virtual int RecvMessage(FDXSMessage &message,int timeout) = 0;
  virtual int CreateTunnle() = 0;
  virtual int FreeTunnle() = 0;
  virtual int ConnectTunnle() = 0;
  virtual int DisconnectTunnle() = 0;
  virtual bool IsDisconnected() = 0;
  std::string tunnle_name() const
  {
    return tunnle_name_;
  }
  std::string last_error() const
  {
    return last_error_;
  }
  void set_last_error(const std::string & error)
  {
    last_error_ = error;
  }
  std::size_t buffer_max_size() const
  {
    return buffer_max_size_;
  }
 protected:
  std::size_t buffer_max_size_;
 private:
  std::string tunnle_name_;
  std::string last_error_;
  
};


bool FDXSLib_Register(const std::string& impl_name,FDXSLibImplFactory &factory);
void FDXSLib_Unregister(const std::string& impl_name);
FDXSCommunication* FDXSLib_CreateImpl(const std::string &namestr,std::size_t max_size);

} // FDXSLib


#endif // _FDXSLIB_SERVER_H_
